package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import fabricaConexoes.Conexao;
import modelo.FotoTirada;

public class FotoTiradaDao {
	Conexao conexao = new Conexao();
	public void insereFotoTirada(FotoTirada i) {
		try {
			
			PreparedStatement ps= conexao.getConexao().prepareStatement(
					"insert into FotoTirada (data, hora)" + 
					"values (?, ?);");
            ps.setString(1, i.getData()); 
            ps.setString(2, i.getHora()); 
            ps.executeUpdate();
 	   	  
 	   } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
 	   }
		
	}
	
	public ResultSet consultaFotoTirada() {
		ResultSet rs = null;
		try {
			Statement stmt= conexao.getConexao().createStatement();     
			rs = stmt.executeQuery("select * from Tirada");	    
 	   } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
 	   }
		return rs;
	}
}
