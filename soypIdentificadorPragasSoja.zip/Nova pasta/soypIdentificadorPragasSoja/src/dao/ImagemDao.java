package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import fabricaConexoes.Conexao;
import modelo.Imagem;

public class ImagemDao {
	Conexao conexao = new Conexao();

	public void insereImagem(Imagem i) {
		try {
			
			PreparedStatement ps= conexao.getConexao().prepareStatement(
					"insert into Imagem (caminho, tipoImagem, resolucao)" + 
					"values (?,?,?);"); 
            ps.setString(1, i.getCaminho());
            ps.setString(2, i.getTipoImagem());
            ps.setString(3, i.getResolucao()); 
            ps.executeUpdate();
 	   	  
 	   } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
 	   }
		
	}
	
	public ResultSet consultaImagem() {
		ResultSet rs = null;
		try {
			Statement stmt= conexao.getConexao().createStatement();     
			rs = stmt.executeQuery("select * from Imagem");	    
 	   } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
 	   }
		return rs;
	}
}
