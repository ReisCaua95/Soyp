package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import fabricaConexoes.Conexao;
import modelo.Praga;


public class PragaDao {
	Conexao conexao = new Conexao();
	
	public void inserePraga(Praga p) {
		try {
			
			PreparedStatement ps= conexao.getConexao().prepareStatement(
					"insert into Praga (nomeComum, nomeCientifico, inicioIncidencia, fimIncidencia, tempoVida)" + 
					"values (?,?,?,?,?);");
			ps.setString(1, p.getNomeComum());
            ps.setString(2, p.getNomeCientifico()); 
            ps.setString(3, p.getInicioIncidencia());  
            ps.setString(4, p.getFimIncidencia());
            ps.setInt(5, p.getTempoVida());
            ps.executeUpdate();
 	   	  
 	   } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
 	   }
		
	}
	
	public ResultSet consultaPraga() {
		ResultSet rs = null;
		try {
			Statement stmt= conexao.getConexao().createStatement();     
			rs = stmt.executeQuery("select * from praga");	    
 	   } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
 	   }
		
		return rs;
	}
}
