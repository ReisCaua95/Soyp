package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import fabricaConexoes.Conexao;
import modelo.Coordenada;

public class CoordenadaDao {
	Conexao conexao = new Conexao();
	
	public void insereCoordenada(Coordenada c) {
		try {
			
			PreparedStatement ps= conexao.getConexao().prepareStatement(
					"insert into Coordenada (latitude, longitude)" + 
					"values (?, ?);"); 
            ps.setDouble(1, c.getLatitude()); 
            ps.setDouble(2, c.getLongitude()); 
            ps.executeUpdate(); 
 	   	  
 	   } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
 	   }
		
	}
	
	public ResultSet consultaCoordenada() {
		ResultSet rs = null;
		try {
			Statement stmt= conexao.getConexao().createStatement();     
			rs = stmt.executeQuery("select * from Coordenada");	    
 	   } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
 	   }
		return rs;
	}
}
