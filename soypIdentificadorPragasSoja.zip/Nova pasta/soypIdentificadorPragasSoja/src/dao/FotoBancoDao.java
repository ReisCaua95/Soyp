package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import fabricaConexoes.Conexao;
import modelo.FotoBanco;


public class FotoBancoDao {
	Conexao conexao = new Conexao();
	public void insereFotoBanco(FotoBanco i) {
		try {
			
			PreparedStatement ps= conexao.getConexao().prepareStatement(
					"insert into Imagem (descricao)" + 
					"values (?);");
            ps.setString(1, i.getDescricao()); 
            ps.executeUpdate();
 	   	  
 	   } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
 	   }
		
	}
	
	public ResultSet consultaImagem() {
		ResultSet rs = null;
		try {
			Statement stmt= conexao.getConexao().createStatement();     
			rs = stmt.executeQuery("select * from Banco");	    
 	   } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
 	   }
		return rs;
	}
}
