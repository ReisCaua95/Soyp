package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import fabricaConexoes.Conexao;
import modelo.Ataque;


public class AtaqueDao {
Conexao conexao = new Conexao();
	
	public void insereAtaque(Ataque a) {
		try {
			
			PreparedStatement ps= conexao.getConexao().prepareStatement(
					"insert into LocalAtaque (nomeLocal, descricao)" + 
					"values (?,?);");
			ps.setString(1, a.getNomeLocal());
            ps.setString(2, a.getDescricao()); 
            ps.executeUpdate();
 	   	  
 	   } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
 	   }
		
	}
	
	public ResultSet consultaAtaque() {
		ResultSet rs = null;
		try {
			Statement stmt= conexao.getConexao().createStatement();     
			rs = stmt.executeQuery("select * from LocalAtaque;");	    
 	   } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
 	   }
		
		return rs;
	}

}
