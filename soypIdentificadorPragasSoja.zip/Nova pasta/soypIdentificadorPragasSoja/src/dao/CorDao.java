package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import fabricaConexoes.Conexao;
import modelo.Cor;


	
	public class CorDao {
		Conexao conexao = new Conexao();
		
		public void insereCor(Cor w) {
			try {
				
				PreparedStatement ps= conexao.getConexao().prepareStatement(
						"insert into Cor (nomeCor)" + 
						"values (?);"); 
	            ps.setString(1, w.getNomeCor()); 
	            ps.executeUpdate(); 
	 	   	  
	 	   } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
	 	   }
			
		}
		
		public ResultSet consultaCor() {
			ResultSet w2 = null;
			try {
				Statement stmt= conexao.getConexao().createStatement();     
				w2 = stmt.executeQuery("select * from Cor;");	    
	 	   } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
	 	   }
			return w2;
		}
	}



