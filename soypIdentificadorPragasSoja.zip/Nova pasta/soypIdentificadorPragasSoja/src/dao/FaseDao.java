package dao;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.sql.Statement;

	import fabricaConexoes.Conexao;
	import modelo.Fase;
		
		public class FaseDao {
			Conexao conexao = new Conexao();
			
			public void insereFase(Fase f) {
				try {
					
					PreparedStatement ps= conexao.getConexao().prepareStatement(
							"insert into Fase (nomeFase, tamanho)" + 
							"values (?,?);"); 
		            ps.setString(1, f.getNomeFase()); 
		            ps.setDouble(2, f.getTamanho()); 
		            ps.executeUpdate(); 
		 	   	  
		 	   } catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
		 	   }
				
			}
			
			public ResultSet consultaFase() {
				ResultSet rs = null;
				try {
					Statement stmt= conexao.getConexao().createStatement();     
					rs = stmt.executeQuery("select * from Fase");	    
		 	   } catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
		 	   }
				return rs;
			}
		


	}


