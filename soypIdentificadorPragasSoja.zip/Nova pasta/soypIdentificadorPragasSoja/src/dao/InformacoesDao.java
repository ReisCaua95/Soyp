package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import fabricaConexoes.Conexao;
import modelo.Fase;

public class InformacoesDao {
	Conexao conexao = new Conexao();
	
	public void insereInformacao(Informacao n) {
		try {
			
			PreparedStatement ps= conexao.getConexao().prepareStatement(
					"insert into Informacao (longitude, latitude, data, hora)" + 
					"values (?,?,?,?);"); 
            ps.setDouble(1, n.getLongitudee()); 
            ps.setDouble(2, n.getLatitude()); 
            ps.setString(1, n.getData()); 
            ps.setString(2, n.getHora()); 
            ps.executeUpdate(); 
 	   	  
 	   } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
 	   }
		
	}
	
	public ResultSet consultaInformacao() {
		ResultSet rs = null;
		try {
			Statement stmt= conexao.getConexao().createStatement();     
			rs = stmt.executeQuery("select * from Informacao");	    
 	   } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
 	   }
		return rs;
	}



}



