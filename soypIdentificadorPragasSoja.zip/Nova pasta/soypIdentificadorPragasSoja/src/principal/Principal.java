package principal;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import dao.AtaqueDao;
import dao.CoordenadaDao;
import dao.CorDao;
import dao.FaseDao;
import dao.FotoBancoDao;
import dao.FotoTiradaDao;
import dao.ImagemDao;
import dao.PragaDao;
import modelo.Ataque;
import modelo.Coordenada;
import modelo.Cor;
import modelo.Fase;
import modelo.FotoBanco;
import modelo.FotoTirada;
import modelo.Praga;

public class Principal {

	public static void main(String[] args) {
		int tempoVida;
		String sexo, nomeCientifico, nomeComum, inicioIncidencia, fimIncidencia, nomeLocal, cor, caminho, tipoImagem, resolucao, data, hora, descricao, nomeFase, nomeCor;
		double latitude, longitude, tamanho;
		
		PragaDao praga = new PragaDao();
		CorDao wDao = new CorDao();
		FaseDao fDao= new FaseDao();
		AtaqueDao aDao = new AtaqueDao();
		ImagemDao i = new ImagemDao();
		CoordenadaDao cdao = new CoordenadaDao();
		
		Scanner entrada = new Scanner(System.in);
		
		int opcao;
		
		System.out.println("ESCOLHA UMA DAS OP��ES: \n1-Inserir Praga\n2-Consultar Pragas\n3-Inserir uma coordenada\n4-Consultar Coordenada\n\nOp��o: ");
		opcao = entrada.nextInt();
		
		switch (opcao){
			case 1:
				System.out.println ("Insira as informa��es a seguir");
				System.out.println ("Nome comum:");
				entrada = new Scanner(System.in);
				nomeComum = entrada.nextLine();
				System.out.println ("Nome cient�fico:");
				entrada = new Scanner(System.in);
				nomeCientifico = entrada.nextLine();
				System.out.println ("Tempo de vida:");
				tempoVida = entrada.nextInt();
				System.out.println ("In�cio da incid�ncia:");
				entrada = new Scanner(System.in);
				inicioIncidencia = entrada.nextLine();
				System.out.println ("Fim da incid�ncia:");
				entrada = new Scanner(System.in);
				fimIncidencia = entrada.nextLine();
				System.out.println ("Local de ataque :");
				entrada = new Scanner(System.in);
				nomeLocal = entrada.nextLine();
				System.out.println ("Cor da praga:");
				entrada = new Scanner(System.in);
				cor = entrada.nextLine();
				System.out.println ("Nome da fase:");
				entrada = new Scanner(System.in);
				nomeFase = entrada.nextLine();
				System.out.println ("tamanho da praga:");
				tamanho = entrada.nextDouble();
				System.out.println ("Descri��o do ataque da praga:");
				entrada = new Scanner(System.in);
				descricao = entrada.nextLine();
		
		
				
				
				Praga p = new Praga (nomeComum, nomeCientifico, inicioIncidencia, fimIncidencia, tempoVida);
				Cor w = new Cor (cor);
				Fase f = new Fase (nomeFase, tamanho);
				Ataque a = new Ataque (nomeLocal, descricao);
		
				
				praga.inserePraga(p);
				aDao.insereAtaque(a);
				wDao.insereCor(w);
				fDao.insereFase(f);
			break;
		
			case 2:
				ResultSet rs = praga.consultaPraga();
				ResultSet w2 = wDao.consultaCor();
				ResultSet a2 = aDao.consultaAtaque();
				ResultSet f2 = fDao.consultaFase();
				
				System.out.println("**************** PRAGAS CATALOGADAS **************** ");
				System.out.println(" ");
	 	   
				try {
					
					while( rs.next() ) {    //move o curso de registros
					   System.out.println( "nome Comum:" + rs.getString("nomeComum"));
					   System.out.println( "nome Cientifico:" + rs.getString("nomeCientifico"));  
					   System.out.println( "In�cio da incid�ncia :" + rs.getString("inicioIncidencia"));  
					   System.out.println( "Fim da incid�ncia:" + rs.getString("fimIncidencia"));   
					   System.out.println( "Tempo de vida:" + rs.getInt("tempoVida")); 
					   
					   while (f2.next()) {
						   System.out.println( "Nome Fase:" + f2.getString("nomeFase"));  
						   System.out.println( "Tamanho da praga:" + f2.getDouble("tamanho"));  
						   while(w2.next()) {
							   System.out.println( "Cor:" + w2.getString("nomeCor"));   
							  
						   }
						   while (a2.next()) {
							   System.out.println( "Local de Ataque:" + a2.getString("nomeLocal"));   
							   System.out.println( "Descri��o:" + a2.getString("descricao"));   
						   }
					   }
					   
					  
					   
					   System.out.println(" ");
					   System.out.println("*******************************************************");
					}
	 		   
				} catch (SQLException e) {
			 		   // TODO Auto-generated catch block
			 		   e.printStackTrace();
				} 
			break;
			
			case 3:
				System.out.println ("Insira as informa��es a seguir");
				System.out.println ("Latitude:");
				latitude = entrada.nextDouble();
				System.out.println ("Longitude:");
				longitude = entrada.nextDouble();
				
				Coordenada c = new Coordenada (latitude, longitude);
				
				cdao.insereCoordenada(c);
				
			break;
			
			case 4:
				ResultSet cs = cdao.consultaCoordenada();
				
				System.out.println("**************** COORDENADAS ARMAZENADAS **************** ");
				System.out.println(" ");
	 	   
				try {
	 		   
					while( cs.next() ) {    //move o curso de registros
					   System.out.println( "Latitude:" + cs.getString("latitude"));  
					   System.out.println( "Longitude:" + cs.getDouble("longitude"));  
					   System.out.println(" ");
					   System.out.println("*******************************************************");
					}
	 		   
				} catch (SQLException e) {
			 		   // TODO Auto-generated catch block
			 		   e.printStackTrace();
				} 
			break;
			
				
		
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			/* case 5:
			System.out.println ("Insira as informa��es a seguir");
			System.out.println ("Caminho da imagem:");
			entrada = new Scanner(System.in);
			caminho = entrada.nextLine();
			System.out.println ("Tipo da imagem:");
			entrada = new Scanner(System.in);
			tipoImagem = entrada.nextLine();
			System.out.println ("Resolu��o:");
			entrada = new Scanner(System.in);
			resolucao = entrada.nextLine();
			System.out.println ("Data:");
			entrada = new Scanner(System.in);
			data = entrada.nextLine();
			System.out.println ("Hora:");
			entrada = new Scanner(System.in);
			hora = entrada.nextLine();
			
			FotoTirada ft = new FotoTirada (caminho, tipoImagem, resolucao, data, hora);
			
			i.insereImagem(ft);
			
			ft2.insereFotoTirada();
			
			
		break;
		
		case 6:
			System.out.println ("Insira as informa��es a seguir");
			System.out.println ("Caminho da imagem:");
			caminho = entrada.next();
			System.out.println ("Tipo da imagem:");
			tipoImagem = entrada.next();
			System.out.println ("Resolu��o:");
			resolucao = entrada.next();
			System.out.println ("Descri��o:");
			descricao = entrada.next();
			
			FotoBanco fb = new FotoBanco (caminho, tipoImagem, resolucao, descricao);
			
			i.insereImagem(fb);
			fb2.insereFotoBanco(fb);
			
		break;*/
			
		}
	}

}
