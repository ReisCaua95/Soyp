package modelo;

public class FotoTirada extends Imagem{
	private String data;
	private String hora;
	
	public FotoTirada(String caminho, String tipoImagem, String resolucao, String data, String hora){
		super(caminho, tipoImagem, resolucao);
		this.data=data;
		this.hora=hora;
	}

	public String getData() {
		return data;
	}

	public void setdata(String data) {
		this.data = data;
	}
	
	public String getHora() {
		return hora;
	}

	public void setHora(String hora) {
		this.hora = hora;
	}
	
	
	
}
