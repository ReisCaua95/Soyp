package modelo;

public class Fase {
	
	String nomeFase;
	double tamanho;
	
	
	public Fase (String nomeFase, double tamanho) {
		this.nomeFase=nomeFase;
		this.tamanho=tamanho;
		
	}


	public String getNomeFase() {
		return nomeFase;
	}


	public void setNomeFase(String nomeFase) {
		this.nomeFase = nomeFase;
	}


	public double getTamanho() {
		return tamanho;
	}


	public void setTamanho(double tamanho) {
		this.tamanho = tamanho;
	}
}
