package modelo;

public class Cor {
	
	String nomeCor;
	
	public Cor(String nomeCor) {
		this.nomeCor=nomeCor;
	}

	public String getNomeCor() {
		return nomeCor;
	}

	public void setNomeCor(String nomeCor) {
		this.nomeCor = nomeCor;
	}

}
