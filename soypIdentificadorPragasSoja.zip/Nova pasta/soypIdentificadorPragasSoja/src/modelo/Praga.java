package modelo;

public class Praga {
	int tempoVida;
	String nomeCientifico, inicioIncidencia, fimIncidencia, nomeComum;
	
	
	public Praga(String nomeComum, String nomeCientifico, String inicioIncidencia, String fimIncidencia, int tempoVida){
		this.nomeComum=nomeComum;
		this.nomeCientifico=nomeCientifico;
		this.inicioIncidencia=inicioIncidencia;
		this.fimIncidencia=fimIncidencia;
		this.tempoVida=tempoVida;
		
	}


	public int getTempoVida() {
		return tempoVida;
	}

	public void setTempoVida(int tempoVida) {
		this.tempoVida = tempoVida;
	}

	public String getNomeCientifico() {
		return nomeCientifico;
	}

	public void setNomeCientifico(String nomeCientifico) {
		this.nomeCientifico = nomeCientifico;
	}

	public String getInicioIncidencia() {
		return inicioIncidencia;
	}

	public void setInicioIncidencia(String inicioIncidencia) {
		this.inicioIncidencia = inicioIncidencia;
	}

	public String getNomeComum() {
		return nomeComum;
	}

	public void setNomeComum(String nomeComum) {
		this.nomeComum = nomeComum;
	}
	public String getFimIncidencia() {
		return fimIncidencia;
	}

	public void setFimIncidencia(String fimIncidencia) {
		this.fimIncidencia = fimIncidencia;
	}


	
}
