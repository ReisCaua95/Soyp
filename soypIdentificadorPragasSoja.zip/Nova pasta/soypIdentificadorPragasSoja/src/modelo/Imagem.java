package modelo;

public abstract class Imagem {

	protected int idImagem;
	protected String caminho, tipoImagem, resolucao;

	public Imagem (String caminho, String tipoImagem, String resolucao){
		this.caminho=caminho;
		this.tipoImagem=tipoImagem;
		this.resolucao=resolucao;
	}

	public String getCaminho() {
		return caminho;
	}

	public void setCaminho(String caminho) {
		this.caminho = caminho;
	}

	public String getTipoImagem() {
		return tipoImagem;
	}

	public void setTipoImagem(String tipoImagem) {
		this.tipoImagem = tipoImagem;
	}

	public String getResolucao() {
		return resolucao;
	}

	public void setResolucao(String resolucao) {
		this.resolucao = resolucao;
	}


}
