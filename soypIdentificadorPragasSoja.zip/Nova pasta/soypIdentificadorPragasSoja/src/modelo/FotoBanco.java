package modelo;

public class FotoBanco extends Imagem  {
	String descricao;
	
	public FotoBanco (String caminho, String tipoImagem, String resolucao, String descricao){
		super(caminho, tipoImagem, resolucao);
		this.descricao=descricao;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	
}
