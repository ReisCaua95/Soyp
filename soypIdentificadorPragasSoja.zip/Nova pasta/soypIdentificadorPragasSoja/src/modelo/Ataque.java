package modelo;

public class Ataque {
	
	 String nomeLocal, descricao;
	 
	 public Ataque ( String nomeLocal, String descricao) {
		 
		 this.nomeLocal=nomeLocal;
		 this.descricao=descricao;
		 
	 }

	public String getNomeLocal() {
		return nomeLocal;
	}

	public void setNomeLocal(String nomeLocal) {
		this.nomeLocal = nomeLocal;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public String getLocalAtaque() {
		// TODO Auto-generated method stub
		return null;
	}

}
