package modelo;

public class Informacoes {
	
	double longitude, latitude;
	String data, hora;
	
	public Informacoes(double longitude, double latitude,
	String data, String hora) {
	this.longitude=longitude;
	this.latitude=latitude;
	this.data=data;
	this.hora=hora;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getHora() {
		return hora;
	}

	public void setHora(String hora) {
		this.hora = hora;
	}
	

}
