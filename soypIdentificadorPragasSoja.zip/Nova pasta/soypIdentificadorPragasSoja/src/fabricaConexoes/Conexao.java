package fabricaConexoes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {
	
	Connection conexao;
	
	public Conexao() {
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			
			conexao = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/soyp", "root", "" );
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}  
		
	}

	public Connection getConexao() {
		return conexao;
	}

	public void setConexao(Connection conexao) {
		this.conexao = conexao;
	}

	
}