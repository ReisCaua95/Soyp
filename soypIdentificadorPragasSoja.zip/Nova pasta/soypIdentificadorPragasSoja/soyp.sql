create database Soyp;
use  Soyp;

create table Praga(
idPraga int not null auto_increment,
nomeComum varchar(100),
nomeCientifico varchar(100),
inicioIncidencia varchar(100),
fimIncidencia varchar(100),
tempoVida int,
primary key (idPraga)
)Engine innodb;

create table Informacoes(
idInfo int not null auto_increment,
latitude double,
longitude double,
horaTirada time,
dataTirada date,
primary key(idInfo)
)engine innodb;

create table Imagem(
idImagem int not null auto_increment,
caminho varchar (500),
formato varchar (30),
tipoImagem varchar (30),
resolucao varchar (30),
idInfo int not null,
idPraga int not null, 
primary key (idImagem),
foreign key (idPraga) references Praga(idPraga),
foreign key (idInfo) references Informacoes(idInfo)
)engine innodb;

create table Fase(
	idFase int not null auto_increment,
    nomeFase varchar(30),
    tamanho double,
    primary key (idFase)
)engine innodb;

-- relacionamento Fase e Praga
create table FasePraga(
	idPraga int not null,
    idFase int not null,
    primary key(idPraga, idFase),
    foreign key(idPraga) references Praga(idPraga),
    foreign key(idFase) references Fase(idFase)
)engine innodb;

create table Cor(
	idCor int not null auto_increment,
    nomeCor varchar(30),
    primary key (idCor)
)engine innodb;

-- relacionamento de cor e Praga
create table CorFase(
	idFase int not null,
    idCor int not null,
    primary key(idFase, idCor),
    foreign key(idFase) references Fase(idFase),
    foreign key(idCor) references Cor(idCor)
)engine innodb;

create table LocalAtaque(
	idLocal int not null auto_increment,
    nomeLocal varchar(30),
    descricao varchar (200),
    primary key (idLocal)
)engine innodb;

-- relacionamento LocalPlanta e Praga
create table LocalAtaqueFase(
	idFase int not null,
    idLocal int not null,
    primary key(idFase, idLocal),
    foreign key(idfase) references Fase(idFase),
    foreign key(idLocal) references LocalAtaque(idLocal)
)engine innodb;

select * from praga;
select * from fase;
select * from LocalAtaque;
select * from cor;

