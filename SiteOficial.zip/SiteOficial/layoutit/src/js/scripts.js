function ValidaForm(){

	if (document.frmlogin.txtemail.value=="")

	{
		(document.frmlogin.txtemail.style.background='yellow');
		alert ("Campo 'E-mail' obrigatório!");
		document.frmlogin.txtemail.focus();
		return false;
	}

	else
		document.frmlogin.txtemail.style.background='white';

	 

	if (document.frmlogin.amigos.checked==false && document.frmlogin.bragantec.checked==false && document.frmlogin.facebook.checked==false && document.frmlogin.outros.checked==false)
		{
			alert ("Favor selecionar uma opção !");
		     return false;
		
		}

	if (document.frmlogin.txtotimo.checked==false && document.frmlogin.txtbom.checked==false && document.frmlogin.txtruim.checked==false) {
		alert ("Por favor, avalie nosso site :( ");
		     return false;


	}
	document.forms[0].action="FormFaleConosco.html";
	document.forms[0].submit();
}