package soyp.com.br.modelo;

public class Praga {
	private String nomeComum, nomeCientifico, localAtaque, caminhoFoto;

	public Praga(String nomeComum, String nomeCientifico, String localAtaque, String caminhoFoto) {
		this.nomeComum = nomeComum;
		this.nomeCientifico = nomeCientifico;
		this.localAtaque = localAtaque;
		this.caminhoFoto = caminhoFoto;
	}

	public String getNomeComum() {
		return nomeComum;
	}

	public void setNomeComum(String nomeComum) {
		this.nomeComum = nomeComum;
	}

	public String getNomeCientifico() {
		return nomeCientifico;
	}

	public void setNomeCientifico(String nomeCientifico) {
		this.nomeCientifico = nomeCientifico;
	}

	public String getLocalAtaque() {
		return localAtaque;
	}

	public void setLocalAtaque(String localAtaque) {
		this.localAtaque = localAtaque;
	}

	public String getCaminhoFoto() {
		return caminhoFoto;
	}

	public void setCaminhoFoto(String caminhoFoto) {
		this.caminhoFoto = caminhoFoto;
	}
	
	
	
	
}
