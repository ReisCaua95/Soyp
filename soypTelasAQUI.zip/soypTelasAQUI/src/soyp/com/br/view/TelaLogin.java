package soyp.com.br.view;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import java.awt.Insets;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import soyp.com.br.controle.CriarUsuarioControle;
import soyp.com.br.dao.UsuarioBanco;
import soyp.com.br.modelo.Usuario;

import java.awt.Font;

public class TelaLogin {
	public static String nomeAtual, senhaAtual;
	public static int idAtual;
	public static void main(String[] args) {
		
			JFrame frame = new JFrame();
			frame.setSize(488, 228);
			
			JPanel panel = new JPanel();
			frame.getContentPane().add(panel);
			
			
			
			JPasswordField senha = new JPasswordField();
			senha.setBounds(120, 90, 237, 26);
			senha.setEchoChar((char)0);
			senha.setColumns(20);
			senha.setText("Senha");
			senha.setSelectedTextColor(Color.GRAY);
			senha.requestFocus();
			
			senha.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					((JPasswordField)e.getSource()).setText("");
					((JPasswordField)e.getSource()).setEchoChar('*');
	
				}
			});
			
			
			JTextField nome = new JTextField();
			nome.setBounds(120, 53, 237, 26);
			nome.setColumns(20);
			nome.setText("Nome de usu�rio");
			nome.setSelectedTextColor(Color.GRAY);
			nome.requestFocus();
			
			nome.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
			((JTextField)e.getSource()).setText("");					
				}
			});
			panel.setLayout(null);
			
			JLabel lblSoyp = new JLabel("SOYP");
			lblSoyp.setFont(new Font("Tempus Sans ITC", Font.BOLD, 20));
			lblSoyp.setHorizontalAlignment(SwingConstants.CENTER);
			lblSoyp.setBounds(120, 15, 237, 27);
			panel.add(lblSoyp);
			
			nome.setCaretPosition(0);
			nome.setCaretColor(Color.BLACK);
			panel.add(nome);
			
			senha.setCaretPosition(0);
			senha.setCaretColor(Color.BLACK);
			panel.add(senha);
			
			
			JButton entrar = new JButton("Entrar");
			entrar.setBounds(120, 127, 86, 23);
			panel.add(entrar);
			JButton criar = new JButton("Criar nova conta");
			criar.setBounds(214, 127, 143, 23);
			panel.add(criar);
			
			frame.setVisible(true);
			
			criar.addActionListener( new ActionListener() {
				
				
				public void actionPerformed(ActionEvent e) {
					frame.setVisible(false);
					CriarUsuario a = new CriarUsuario();
					
					//CriarUsuario cuc = new CriarUsuarioControle(CriarUsuario telaCriar, Usuario usuario);
					
					
				}
			});
			
			entrar.addActionListener( new ActionListener() {
				
				
				public void actionPerformed(ActionEvent e) {
					if(nome.getText().equals("Nome de usu�rio") || senha.getText().equals("Senha") && nome.getText().equals("") || senha.getText().equals("") ) {
						TelaErro erro = new TelaErro("O usu�rio n�o foi cadastrado!");
						erro.mostrarErro("O usu�rio n�o foi cadastrado!");
					}else {
						ResultSet rs;
						UsuarioBanco u = new UsuarioBanco();
						rs = u.consultaUsuario();
						boolean acesso = false;
						try {
							while(rs.next()) {
								if(nome.getText().equals(rs.getString("nome")) && senha.getText().equals(rs.getString("senha"))) {
									acesso = true;
									nomeAtual = rs.getString("nome");
									senhaAtual = rs.getString("senha");
									idAtual = rs.getInt("id");
									break;
								}else {
									acesso = false;
								}
							}
							
							if(acesso == true) {
								frame.setVisible(false);
								TelaMenu b = new TelaMenu();
								b.mostrartela3();
								
							}else {
								if(acesso == false) {
									TelaErro erro = new TelaErro("O usu�rio n�o foi cadastrado!");
									erro.mostrarErro("O usu�rio n�o foi cadastrado!");
								}
							}
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						
						
					}
				}
			});

		
	}

	

}
