package soyp.com.br.view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.SwingConstants;

import soyp.com.br.modelo.Usuario;

import javax.swing.JButton;

public class CadastroOK {

	private JFrame frame;
	private JLabel lblCa;
	
	
	

	public JLabel getLblCa() {
		return lblCa;
	}

	public void setLblCa(JLabel lblCa) {
		this.lblCa = lblCa;
	}

	public CadastroOK() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		lblCa = new JLabel("Cadastro Realizado com Sucesso!!");
		lblCa.setBounds(0, 56, 434, 90);
		lblCa.setHorizontalAlignment(SwingConstants.CENTER);
		lblCa.setFont(new Font("Tempus Sans ITC", Font.PLAIN, 24));
		frame.getContentPane().add(lblCa);
		
		JButton btnNewButton = new JButton("ok!");
		btnNewButton.setBounds(119, 138, 175, 23);
		frame.getContentPane().add(btnNewButton);
		
		frame.setVisible(true);
		
		btnNewButton.addActionListener( new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				TelaLogin c = new TelaLogin();
				c.main(null);
				
		
				//CriarUsuario cuc = new CriarUsuarioControle(CriarUsuario telaCriar, Usuario usuario);
				
				
			}
		});
	}

}
