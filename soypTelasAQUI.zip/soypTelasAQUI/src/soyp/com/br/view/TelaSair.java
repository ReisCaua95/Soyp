package soyp.com.br.view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.LineBorder;
import java.awt.Color;
import java.awt.Font;
import java.awt.FlowLayout;

public class TelaSair {

	private JFrame frame;
	private boolean cont;
	private int telaAnterior;
	
	
	
	

	public void mostrartela7(int a) {
		
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaSair window = new TelaSair(a);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
	
	}

	/**
	 * Create the application.
	 */
	public TelaSair(int a) {
		this.telaAnterior = a;
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		frame = new JFrame();
		frame.setBounds(100, 100, 520, 314);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblSair = new JLabel("SAIR");
		lblSair.setFont(new Font("Tempus Sans ITC", Font.BOLD, 20));
		lblSair.setHorizontalAlignment(SwingConstants.CENTER);
		lblSair.setBounds(120, 25, 275, 42);
		panel.add(lblSair);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_1.setBounds(120, 94, 275, 97);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblVocTemCerteza = new JLabel("Voc\u00EA tem certeza de que deseja sair?");
		lblVocTemCerteza.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblVocTemCerteza.setHorizontalAlignment(SwingConstants.CENTER);
		lblVocTemCerteza.setBounds(0, 11, 275, 14);
		panel_1.add(lblVocTemCerteza);
		
		JButton sim = new JButton("Sim");
		sim.setBounds(32, 47, 89, 35);
		panel_1.add(sim);
		
		JButton nao = new JButton("N\u00E3o");
		nao.setBounds(152, 47, 89, 35);
		panel_1.add(nao);
		
		sim.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				TelaLogin tl1 = new TelaLogin();
				tl1.main(null);
				
				
			}
			
			
		});
		
		nao.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				
				
				switch(telaAnterior) {
					case 3:
						TelaMenu b = new TelaMenu();
						b.mostrartela3();
					break;
					
					case 4:
						TelaPraga c = new TelaPraga();
					break;
					
					case 5:
						TelaSoja d = new TelaSoja();
						d.mostrartela5();
					break;
					
					case 6:
						TelaFaleConosco f = new TelaFaleConosco();
						f.mostrartela6();
					break;
				}
				
			}
		});
		
	}

	
	
	

}
