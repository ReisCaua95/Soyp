package soyp.com.br.view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.UIManager;
import javax.swing.JButton;

public class TelaErro {

	private JFrame frame;
	String msg;
	/**
	 * Launch the application.
	 */
	public void mostrarErro(String a) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaErro window = new TelaErro(a);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public TelaErro(String a) {
		this.msg=a;
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 682, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_1.setBounds(67, 44, 539, 154);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel Ltexo = new JLabel();
		Ltexo.setFont(new Font("Tahoma", Font.PLAIN, 16));
		Ltexo.setBounds(0, 68, 539, 29);
		Ltexo.setText(msg);
		panel_1.add(Ltexo);
		Ltexo.setHorizontalAlignment(SwingConstants.CENTER);
		
		JLabel lblNewLabel = new JLabel("ERRO!");
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setBounds(0, 30, 554, 27);
		panel_1.add(lblNewLabel);
		lblNewLabel.setFont(new Font("Tempus Sans ITC", Font.PLAIN, 20));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		
		JButton tentar = new JButton("Tentar Novamente!");
		tentar.setBounds(182, 108, 176, 23);
		panel_1.add(tentar);
		
		tentar.addActionListener( new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				
				
			}
		});
	}
}
