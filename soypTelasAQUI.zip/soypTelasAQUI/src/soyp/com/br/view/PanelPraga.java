package soyp.com.br.view;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextPane;
import javax.swing.border.LineBorder;

import soyp.com.br.modelo.Praga;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;

public class PanelPraga {

	private JPanel panel;
	private final JLabel foto = new JLabel("Foto");
	private JLabel nomeComum;
	private JLabel nomeCientifico;
	private JButton maisBtn ;
	private JLabel localDeAtaque;
	
	public JButton getMaisBtn() {
		return maisBtn;
	}

	public JLabel getNomeComum() {
		return nomeComum;
	}
	
	public JPanel getPanel() {
		return panel;
	}


	public JLabel getFoto() {
		return foto;
	}

	public JLabel getNomeCientifico() {
		return nomeCientifico;
	}

	public JLabel getLocalDeAtaque() {
		return localDeAtaque;
	}
	

	public PanelPraga() {
		initialize();
		
	}
	
	

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		panel = new JPanel();
		
		panel.setBackground(Color.WHITE);
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel.setPreferredSize(new Dimension(380, 79));

		panel.setLayout(null);
		
		
		foto.setBounds(15, 11, 63, 53);
		panel.add(foto);
		
			
		nomeComum = new JLabel("Nome comum: ");
		nomeComum.setBounds(88, 11, 211, 14);
		panel.add(nomeComum);
		
		nomeCientifico = new JLabel("Nome cientifico:");
		nomeCientifico.setBounds(88, 30, 211, 14);
		panel.add(nomeCientifico);
		
		maisBtn = new JButton("Saber mais");
		maisBtn.setBounds(372, 41, 115, 23);
		panel.add(maisBtn);
		
		localDeAtaque = new JLabel("Local de ataque:");
		localDeAtaque.setBounds(88, 50, 211, 14);
		panel.add(localDeAtaque);
		
	}


	
	


}
