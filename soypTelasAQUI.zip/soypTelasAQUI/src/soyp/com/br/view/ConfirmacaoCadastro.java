package soyp.com.br.view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

import soyp.com.br.modelo.Usuario;

import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.SwingConstants;
import javax.swing.JButton;

public class ConfirmacaoCadastro {

	private JFrame frame;
	private JLabel senhaL;
	private JLabel nomeL;
	private JButton ok;
	private JButton btnEditar;
	
	
	
	public JButton getBtnEditar() {
		return btnEditar;
	}



	public JFrame getFrame() {
		return frame;
	}


	public JButton getOk() {
		return ok;
	}


	public JLabel getSenhaL() {
		return senhaL;
	}



	public JLabel getNomeL() {
		return nomeL;
	}



	
	public void confimar() {
		
		frame.setVisible(true);
	}


	
	public ConfirmacaoCadastro() {
		
		initialize();
	}

	
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel.setBounds(57, 42, 318, 172);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblCadastroRealizadoCom = new JLabel("Cadastro Realizado com Sucesso!");
		lblCadastroRealizadoCom.setHorizontalAlignment(SwingConstants.CENTER);
		lblCadastroRealizadoCom.setFont(new Font("Tempus Sans ITC", Font.PLAIN, 20));
		lblCadastroRealizadoCom.setBounds(10, 11, 298, 45);
		panel.add(lblCadastroRealizadoCom);
		
		ok = new JButton("Ok");
		ok.setBounds(20, 138, 126, 23);
		panel.add(ok);
		
		JLabel lblConfiraSeusDados = new JLabel("Confira seus dados:");
		lblConfiraSeusDados.setBounds(20, 58, 198, 14);
		panel.add(lblConfiraSeusDados);
		
		
		nomeL = new JLabel();
		nomeL.setBounds(40, 83, 157, 14);
		nomeL.setText("Nome: ");
		panel.add(nomeL);
	
		senhaL = new JLabel();
		senhaL.setBounds(40, 108, 157, 14);
		senhaL.setText("Senha: ");
		panel.add(senhaL);
		
		btnEditar = new JButton("Editar");
		btnEditar.setBounds(156, 138, 134, 23);
		panel.add(btnEditar);
		
	
		
		
		
	}
}
