package soyp.com.br.view;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.SwingConstants;

import soyp.com.br.dao.UsuarioBanco;

public class Editar {

	private JFrame frame;
	private JTextField txtNomeDeUsuario;
	private JTextField txtCrieUmaSenha;
	private JTextField txtConfirmarSenha;


	/**
	 * Create the application.
	 */
	public Editar() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 434, 261);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		txtNomeDeUsuario = new JTextField();
		txtNomeDeUsuario.setText(TelaLogin.nomeAtual);
		txtNomeDeUsuario.setBounds(132, 68, 166, 26);
		panel.add(txtNomeDeUsuario);
		txtNomeDeUsuario.setColumns(10);
		
		txtCrieUmaSenha = new JTextField();
		txtCrieUmaSenha.setText(TelaLogin.senhaAtual);
		txtCrieUmaSenha.setBounds(132, 105, 166, 26);
		panel.add(txtCrieUmaSenha);
		txtCrieUmaSenha.setColumns(10);
		
		JLabel lblEditarCadastro = new JLabel("Editar Cadastro");
		lblEditarCadastro.setHorizontalAlignment(SwingConstants.CENTER);
		lblEditarCadastro.setFont(new Font("Tempus Sans ITC", Font.PLAIN, 22));
		lblEditarCadastro.setBounds(132, 27, 166, 30);
		panel.add(lblEditarCadastro);
		
		JButton btnSalvar = new JButton("Salvar");
		btnSalvar.setBounds(209, 174, 89, 23);
		panel.add(btnSalvar);
		
		
		
		txtConfirmarSenha = new JTextField();
		txtConfirmarSenha.setText(TelaLogin.senhaAtual);
		txtConfirmarSenha.setBounds(132, 137, 166, 26);
		panel.add(txtConfirmarSenha);
		txtConfirmarSenha.setColumns(10);
		
		JButton btnNewButton = new JButton("Voltar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						frame.setVisible(false);
						ConsultarCadastro c = new ConsultarCadastro();
									
					
			}
		});
		btnNewButton.setBounds(131, 174, 68, 23);
		panel.add(btnNewButton);
		
		frame.setVisible(true);
		
		btnSalvar.addActionListener( new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				if(txtCrieUmaSenha.getText().equals(txtConfirmarSenha.getText()) && txtNomeDeUsuario.getText().length()>0) {
					
					UsuarioBanco u = new UsuarioBanco();
					u.atualizarUsuario(txtNomeDeUsuario.getText(), txtCrieUmaSenha.getText());
					CadastroOK cok = new CadastroOK();
					frame.setVisible(false);
					cok.getLblCa().setText("Altera��es realizadas com Sucesso!!");
				}else {
					TelaErro erro = new TelaErro("O nome n�o foi inserido ou as senhas n�o s�o coincidentes!");
					erro.mostrarErro("O nome n�o foi inserido ou as senhas n�o s�o coincidentes!");	
				}
				
				
				
				
			}
		});
	
		
	
		
	}
}
