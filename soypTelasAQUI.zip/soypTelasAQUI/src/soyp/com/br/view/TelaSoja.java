package soyp.com.br.view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollBar;
import javax.swing.JTextPane;
import java.awt.Color;
import javax.swing.UIManager;
import javax.swing.border.LineBorder;
import javax.swing.JTextField;
import java.awt.FlowLayout;
import java.awt.CardLayout;
import java.awt.Font;

public class TelaSoja {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public void mostrartela5() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaSoja window = new TelaSoja();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public TelaSoja() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 596, 420);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		panel.setForeground(UIManager.getColor("Button.darkShadow"));
		panel.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblOMundoDa = new JLabel("O MUNDO DA SOJA");
		lblOMundoDa.setFont(new Font("Tempus Sans ITC", Font.PLAIN, 20));
		lblOMundoDa.setHorizontalAlignment(SwingConstants.CENTER);
		lblOMundoDa.setBounds(41, 11, 485, 33);
		panel.add(lblOMundoDa);
		
		JButton ut = new JButton("Utiliza\u00E7\u00F5es");
		ut.setBounds(41, 55, 117, 35);
		panel.add(ut);
		
		JButton ec = new JButton("Economia");
		ec.setBounds(154, 55, 117, 35);
		panel.add(ec);
		
		JButton mo = new JButton("Morfologia");
		mo.setBounds(270, 55, 105, 35);
		panel.add(mo);
		
		JButton his = new JButton("Hist\u00F3ria");
		his.setBounds(372, 55, 89, 35);
		panel.add(his);
		
		JPanel telas = new JPanel();
		telas.setBorder(new LineBorder(new Color(0, 0, 0), 1, true));
		telas.setBounds(41, 88, 485, 244);
		panel.add(telas);
		telas.setLayout(new CardLayout(0, 0));
		
		JPanel p1 = new JPanel();
		telas.add(p1, "historia");
		p1.setLayout(null);
		
		JTextPane txtpnAHistriaDa = new JTextPane();
		txtpnAHistriaDa.setBackground(UIManager.getColor("Button.background"));
		txtpnAHistriaDa.setText("A Hist\u00F3ria da soja\r\n\r\nA hist\u00F3ria da soja \u00E9 um tanto enigm\u00E1tica, pois n\u00E3o se sabe ao certo quais s\u00E3o suas origens. Muitos autores discordam sobre o local exato de seu surgimento, por\u00E9m todos indicam que este teria ocorrido no leste da \u00C1sia. Escritos antigos da China relatam que a soja, j\u00E1 fazia parte da alimenta\u00E7\u00E3o das pessoas, h\u00E1 centenas de anos antes de seus primeiros registros de cultivo. O registro mais antigo, presente no erv\u00E1rio Pen Ts\u2019ao Kang Mu, tem data de 2838 a.C. e recomenda\u00E7\u00F5es a respeito de como realizar a colheita, qual o melhor solo para o plantio, diferentes esp\u00E9cies e utiliza\u00E7\u00F5es datam desde 2207 a.C. Em virtude disto, pode-se dizer que a soja seria uma das esp\u00E9cies mais antigas que o homem j\u00E1 cultivou.\r\n\r\nNo Brasil\r\n\r\nEm 2018 a sojicultura completa 136 anos de exist\u00EAncia no Brasil. O primeiro registro sobre soja em solos brasileiros ocorreu na Bahia em 1882. Gustavo D\u2019utra foi o respons\u00E1vel por relatar os diversos testes, com diferentes esp\u00E9cies, que foram realizados em v\u00E1rios pontos do pa\u00EDs, como na cidade de Campinas no estado de S\u00E3o Paulo na Esta\u00E7\u00E3o Agron\u00F4mica de Campinas, atual Instituto Agron\u00F4mico de Campinas. \r\n\r\nCom o objetivo de impulsionar o cultivo de soja no Brasil, em 1900, a Secretaria de Agricultura, Com\u00E9rcio e Obras P\u00FAblicas do Estado de S\u00E3o Paulo distribuiu sementes para 70 pessoas. Os resultados obtidos por meio dessa estrat\u00E9gia foram excelentes e contribu\u00EDram para disseminar a planta para outras regi\u00F5es do pa\u00EDs.");
		txtpnAHistriaDa.setBounds(10, 5, 418, 226);
		p1.add(txtpnAHistriaDa);
		
		JScrollBar scrollBar = new JScrollBar();
		scrollBar.setBounds(438, 5, 44, 226);
		p1.add(scrollBar);
		
		JPanel p2 = new JPanel();
		telas.add(p2, "morfologia");
		p2.setLayout(null);
		
		JTextPane txtpnAMorfologiaDa = new JTextPane();
		txtpnAMorfologiaDa.setText("A Morfologia da Soja\r\n\r\nNo Brasil, a soja habitualmente cultivada para a obten\u00E7\u00E3o de gr\u00E3os \u00E9 a Glycine max, que faz parte do grupo das angiospermas e classifica-se como uma eudicotiled\u00F4nea.\r\nSeu caule \u00E9 h\u00EDspido (coberto de pelos) e t\u00EAm poucas ramifica\u00E7\u00F5es, a raiz \u00E9 pivotante (possui um eixo principal desenvolvido) e bastante ramificada, suas folhas s\u00E3o trifolioladas (exceto no primeiro par do n\u00F3 acima do n\u00F3 cotiledonar).\r\n\r\nSuas flores s\u00E3o roxas, brancas ou intermedi\u00E1rias e possuem car\u00E1ter aut\u00F3gamo (hermafroditas que se autopolinizam), o que \u00E9 t\u00EDpico da subfam\u00EDlia Papileonoideae.\r\nDesenvolvem vagens que conforme amadurecem mudam da cor verde para amarelo-p\u00E1lido, marrom, cinza ou marrom-claro, e possuem entre uma e cinco sementes lisas e globosas, com tegumento (revestimento externo da semente) amarelo p\u00E1lido e com hilo preto, marrom, ou amarelo-palha.");
		txtpnAMorfologiaDa.setBackground(UIManager.getColor("Button.background"));
		txtpnAMorfologiaDa.setBounds(10, 11, 418, 220);
		p2.add(txtpnAMorfologiaDa);
		
		JScrollBar scrollBar_1 = new JScrollBar();
		scrollBar_1.setBounds(438, 11, 44, 231);
		p2.add(scrollBar_1);
		
		JPanel p3 = new JPanel();
		telas.add(p3, "economia");
		p3.setLayout(null);
		
		JTextPane txtpnAImportnciaEconomia = new JTextPane();
		txtpnAImportnciaEconomia.setText("A import\u00E2ncia Economia da Soja\r\n\r\nO Brasil \u00E9 o segundo maior produtor de soja do mundo. Como visto no t\u00F3pico Hist\u00F3ria da Soja, com o decorrer dos anos a soja foi se espalhando pelo Brasil, chegando a alcan\u00E7ar regi\u00F5es de cerrado e no norte e nordeste do pa\u00EDs. Isso ocorreu, devido aos avan\u00E7os tecnol\u00F3gicos, que permitiram que a soja se adaptasse as diversas condi\u00E7\u00F5es edafoclim\u00E1ticas do solo brasileiro. Estudos apontam que al\u00E9m de possuir tais tecnologias, o Brasil possui muitos territ\u00F3rios para onde possa expandir o plantio da oleaginosa, possibilitando que o pa\u00EDs ultrapasse, em breve, o maior produtor mundial de soja, os Estados Unidos.\r\nA soja \u00E9 uma das bases que movimentam a economia brasileira e nos \u00FAltimos anos tem apresentado um crescimento continuo da \u00E1rea plantada. Segundo a Conab (Companhia Nacional de Abastecimento) a \u00E1rea plantada de soja no Brasil na safra de 2012/2013 era de aproximadamente 27 milh\u00F5es de hectares, j\u00E1 na ultima safra de 2017/2018 esse n\u00FAmero aumentou em cerca de 8 milh\u00F5es de hectares, atingindo uma \u00E1rea plantada de 35,150 milh\u00F5es de hectares. Durante o per\u00EDodo analisado, de 2012 a 2018, a \u00E1rea planta apresentou constante aumento, como pode ser visto no gr\u00E1fico 1, o que mostra o quanto o mercado da soja tem crescido e se tornado uma importante produ\u00E7\u00E3o no pa\u00EDs.");
		txtpnAImportnciaEconomia.setBackground(UIManager.getColor("Button.background"));
		txtpnAImportnciaEconomia.setBounds(10, 11, 418, 220);
		p3.add(txtpnAImportnciaEconomia);
		
		JScrollBar scrollBar_2 = new JScrollBar();
		scrollBar_2.setBounds(429, 11, 44, 220);
		p3.add(scrollBar_2);
		
		JPanel p4 = new JPanel();
		telas.add(p4, "utilizacao");
		p4.setLayout(null);
		
		JTextPane txtpnAUtilizaoDa = new JTextPane();
		txtpnAUtilizaoDa.setBounds(10, 11, 411, 226);
		p4.add(txtpnAUtilizaoDa);
		txtpnAUtilizaoDa.setBackground(UIManager.getColor("Button.background"));
		txtpnAUtilizaoDa.setText("A Utiliza\u00E7\u00E3o da Soja\r\n\r\nAnteriormente, as utiliza\u00E7\u00F5es da soja mais conhecidas, eram obtidas atrav\u00E9s da extra\u00E7\u00E3o de seu \u00F3leo vegetal, seguido de seu subproduto, o farelo da soja.\r\n\r\nEntretanto, a popula\u00E7\u00E3o oriental detinha grande conhecimento sobre tal leguminosa e passa a criar novas formas de utilizar os seus gr\u00E3os.\r\n\r\nAtualmente os gr\u00E3os da soja tamb\u00E9m podem ser utilizados para a produ\u00E7\u00E3o de leite de soja, miss\u00F4 (massa de soja cozida), tofu (queijo feito com soja), molho de soja (liquido obtido pela fermenta\u00E7\u00E3o dos gr\u00E3os de soja), farinha de soja e podem ser ingeridos, assados ou tostados.\r\n\r\nO seu \u00F3leo vegetal, \u00E9 rico em \u00E1cidos graxos (84,15%). No \u00E2mbito aliment\u00EDcio \u00E9 utilizado, normalmente, como \u00F3leo de salada, fritura e na produ\u00E7\u00E3o de manteiga ou margarina. Al\u00E9m disso, possui aplica\u00E7\u00F5es industriais, como o biodiesel, tintas de canetas, xampus, detergentes e sab\u00F5es.\r\n\r\nO farelo de soja, comumente, \u00E9 empregado como suplemento prot\u00E9ico para os animais, como o gado, aves dom\u00E9sticas e su\u00EDnos. Al\u00E9m de que, serve como substituto do leite para os bezerros e \u00E9 usado como alimento de alguns tipos de peixes.\r\n\r\nJ\u00E1 a farinha de soja, \u00E9 utilizada na fabrica\u00E7\u00E3o de ra\u00E7\u00F5es de animais. No \u00E2mbito alimentar \u00E9 empregada na produ\u00E7\u00E3o de massas, cereais, carne de soja, biscoitos, p\u00E3es, entre outros. Ademais atua como um grande auxiliar nos processos de fermenta\u00E7\u00E3o");
		
		JScrollBar scrollBar_3 = new JScrollBar();
		scrollBar_3.setBounds(431, 11, 42, 220);
		p4.add(scrollBar_3);
		
		JButton voltar = new JButton("Voltar");
		voltar.setBounds(323, 343, 89, 23);
		panel.add(voltar);
		
		JButton sair = new JButton("Sair");
		sair.setBounds(437, 343, 89, 23);
		panel.add(sair);
		
		voltar.addActionListener( new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				TelaMenu c = new TelaMenu();
				c.mostrartela3();
				
			}
		});
		
		sair.addActionListener( new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				TelaSair es = new TelaSair(5);
				es.mostrartela7(5);
				
			}
		});
		
		ut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CardLayout layout = (CardLayout)(telas.getLayout());						
				layout.show(telas, "utilizacao");
			}
		});
		
		ec.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CardLayout layout = (CardLayout)(telas.getLayout());						
				layout.show(telas, "economia");
			}
		});
		
		mo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CardLayout layout = (CardLayout)(telas.getLayout());						
				layout.show(telas, "morfologia");
			}
		});
		
		his.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CardLayout layout = (CardLayout)(telas.getLayout());						
				layout.show(telas, "historia");
			}
		});
		
		
		
	}
}
