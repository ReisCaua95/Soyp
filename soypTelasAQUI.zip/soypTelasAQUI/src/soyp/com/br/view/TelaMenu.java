package soyp.com.br.view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.SwingConstants;

import soyp.com.br.controle.PanelPragaControle;
import soyp.com.br.controle.PanelTelaPragaControle;
import soyp.com.br.dao.UsuarioBanco;
import soyp.com.br.modelo.Praga;

import java.awt.CardLayout;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class TelaMenu {

	private JFrame frame;
	
	/**
	 * Launch the application.
	 */
	public void mostrartela3() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaMenu window = new TelaMenu();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public TelaMenu() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 520, 339);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblMenu = new JLabel("MENU");
		lblMenu.setFont(new Font("Tempus Sans ITC", Font.PLAIN, 20));
		lblMenu.setHorizontalAlignment(SwingConstants.CENTER);
		lblMenu.setBounds(118, 23, 276, 28);
		panel.add(lblMenu);
		
		JButton catalogo = new JButton("Cat\u00E1logo");
		catalogo.setBounds(118, 62, 133, 72);
		panel.add(catalogo);
		
		JButton fale = new JButton("Fale conosco");
		fale.setBounds(118, 145, 133, 72);
		panel.add(fale);
		
		JButton soja = new JButton("A soja\r\n");
		soja.setBounds(261, 62, 133, 72);
		panel.add(soja);
		
		JButton sair = new JButton("Sair");
		sair.setBounds(118, 239, 276, 23);
		panel.add(sair);
		
		JButton btnConsultarCadastro = new JButton("Perfil");
		btnConsultarCadastro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frame.setVisible(false);
				
				ConsultarCadastro cc = new ConsultarCadastro();
				
				
				
				
			
				
			}
			
		});
		btnConsultarCadastro.setBounds(261, 145, 133, 72);
		panel.add(btnConsultarCadastro);
		
		fale.addActionListener( new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				TelaFaleConosco c = new TelaFaleConosco();
				c.mostrartela6();
				
			}
		});
		
		catalogo.addActionListener( new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				Praga p = new Praga ("caua", "caua reis", "raiz", "F:\\3� INFO\\Mat�rias T�cnicas\\soypTelas\\img\\vaquinha1.1.jpg");
				PanelPraga pragaPanel = new PanelPraga();
				PanelPragaControle pragaPanelControle = new PanelPragaControle(p, pragaPanel);
				pragaPanelControle.inicializaControle();
				TelaPraga telaPraga = new TelaPraga();
				PanelTelaPragaControle ptpc = new PanelTelaPragaControle(pragaPanel, telaPraga);
				ptpc.adicionaPanelTelaPraga();	
				
				Praga p2 = new Praga ("jady", "jady martins", "folha", "F:\\3� INFO\\Mat�rias T�cnicas\\soypTelas\\img\\vaquinha1.1.jpg");
				PanelPraga pragaPanel2 = new PanelPraga();
				PanelPragaControle pragaPanelControle2 = new PanelPragaControle(p2, pragaPanel2);
				pragaPanelControle2.inicializaControle();
				PanelTelaPragaControle ptpc2 = new PanelTelaPragaControle(pragaPanel2, telaPraga);
				ptpc2.adicionaPanelTelaPraga();	
				
				Praga p3 = new Praga ("sthe", "sthe pragona", "caule", "F:\\3� INFO\\Mat�rias T�cnicas\\soypTelas\\img\\vaquinha1.1.jpg");
				PanelPraga pragaPanel3 = new PanelPraga();
				PanelPragaControle pragaPanelControle3 = new PanelPragaControle(p3, pragaPanel3);
				pragaPanelControle3.inicializaControle();
				PanelTelaPragaControle ptpc3 = new PanelTelaPragaControle(pragaPanel3, telaPraga);
				ptpc3.adicionaPanelTelaPraga();	
				
				Praga p4 = new Praga ("sthe", "sthe pragona", "caule", "F:\\3� INFO\\Mat�rias T�cnicas\\soypTelas\\img\\vaquinha1.1.jpg");
				PanelPraga pragaPanel4 = new PanelPraga();
				PanelPragaControle pragaPanelControle4 = new PanelPragaControle(p4, pragaPanel4);
				pragaPanelControle4.inicializaControle();
				PanelTelaPragaControle ptpc4 = new PanelTelaPragaControle(pragaPanel4, telaPraga);
				ptpc4.adicionaPanelTelaPraga();
				
				Praga p5 = new Praga ("sthe", "sthe pragona", "caule", "F:\\3� INFO\\Mat�rias T�cnicas\\soypTelas\\img\\vaquinha1.1.jpg");
				PanelPraga pragaPanel5 = new PanelPraga();
				PanelPragaControle pragaPanelControle5 = new PanelPragaControle(p5, pragaPanel5);
				pragaPanelControle5.inicializaControle();
				PanelTelaPragaControle ptpc5 = new PanelTelaPragaControle(pragaPanel5, telaPraga);
				ptpc5.adicionaPanelTelaPraga();
			}
		});
		
		sair.addActionListener( new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				TelaSair es = new TelaSair(3);
				es.mostrartela7(3);
				
				
				
			}
		});
		
		soja.addActionListener( new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				TelaSoja r = new TelaSoja();
				r.mostrartela5();
				
			}
		});

			
	}
	
	
}
