package soyp.com.br.view;

import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.SwingConstants;

import soyp.com.br.controle.ConfirmacaoCadastroControle;
import soyp.com.br.controle.CriarUsuarioControle;
import soyp.com.br.dao.UsuarioBanco;
import soyp.com.br.modelo.Usuario;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;



public class CriarUsuario {

	//UsuarioBanco u = new UsuarioBanco();
	private JFrame frame;
	private static JPasswordField passwordField;
	private JPasswordField Csenha;
	private JTextField nome;
	private JPasswordField senha;
	private JButton criar;
	private JButton btnNewButton; 
	

	
	public JButton getBtnNewButton() {
		return btnNewButton;
	}


	public void setBtnNewButton(JButton btnNewButton) {
		this.btnNewButton = btnNewButton;
	}


	public JFrame getFrame() {
		return frame;
	}

	
	public JButton getCriar() {
		return criar;
	}

	public JPasswordField getCsenha() {
		return Csenha;
	}

	public JTextField getNome() {
		return nome;
	}

	public JPasswordField getSenha() {
		return senha;
	}

	public CriarUsuario() {
		initialize();
	}

	
	
	
	private void initialize() {
		mostrartela2();
	}
	


	public void mostrartela2() {
		frame = new JFrame();
		frame.setSize(447, 258);
		
		JPanel panel = new JPanel();
		frame.getContentPane().add(panel);
	
		senha = new JPasswordField();
		senha.setBounds(132, 93, 166, 26);
		senha.setEchoChar((char)0);
		senha.setColumns(20);
		senha.setText("Crie uma senha");
		senha.setSelectedTextColor(Color.GRAY);
		senha.requestFocus();
		
				
		nome = new JTextField();
		nome.setBounds(132, 62, 166, 26);
		nome.setColumns(20);
		nome.setText("Nome de usu�rio");
		nome.setSelectedTextColor(Color.GRAY);
		nome.requestFocus();
		panel.setLayout(null);
		
		JLabel lblSoyp = new JLabel("SOYP");
		lblSoyp.setHorizontalAlignment(SwingConstants.CENTER);
		lblSoyp.setBounds(132, 30, 166, 27);
		panel.add(lblSoyp);
		
		nome.setCaretPosition(0);
		nome.setCaretColor(Color.BLACK);
		panel.add(nome);
		
		senha.setCaretPosition(0);
		senha.setCaretColor(Color.BLACK);
		panel.add(senha);
		
		Csenha = new JPasswordField();
		Csenha.setBounds(132, 124, 166, 26);
		Csenha.setEchoChar((char)0);
		Csenha.setColumns(20);
		Csenha.setText("Confirmar sua senha");
		Csenha.setSelectedTextColor(Color.GRAY);
		Csenha.requestFocus();
		panel.add(Csenha);
		
		criar = new JButton("Criar");
		criar.setBounds(217, 161, 81, 23);
		panel.add(criar);
		
		
		

		


		btnNewButton = new JButton("Voltar");
		
		
		btnNewButton.setBounds(132, 161, 75, 23);
		panel.add(btnNewButton);
		
		frame.setVisible(true);
		
		
		CriarUsuarioControle cuc = new CriarUsuarioControle(this);
		cuc.inicializaControle();
		
		
		
		
	}
}
