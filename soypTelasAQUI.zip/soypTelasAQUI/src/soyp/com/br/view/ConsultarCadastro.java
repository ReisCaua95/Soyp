package soyp.com.br.view;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;

import soyp.com.br.dao.UsuarioBanco;
import soyp.com.br.view.TelaFaleConosco;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JList;
import javax.swing.SwingConstants;
import javax.swing.JTextPane;
import java.awt.Font;

public class ConsultarCadastro {

	private JFrame frame;
	private JLabel lblNome;
	private JLabel lblSenha;

	public JLabel getLblNome() {
		return lblNome;
	}

	public void setLblNome(JLabel lblNome) {
		this.lblNome = lblNome;
	}

	public JLabel getLblSenha() {
		return lblSenha;
	}

	public void setLblSenha(JLabel lblSenha) {
		this.lblSenha = lblSenha;
	}

	/**
	 * Create the application.
	 */
	public ConsultarCadastro() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 444, 261);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblConsultaCadastro = new JLabel("PERFIL DO USU\u00C1RIO");
		lblConsultaCadastro.setFont(new Font("Tempus Sans ITC", Font.PLAIN, 22));
		lblConsultaCadastro.setHorizontalAlignment(SwingConstants.CENTER);
		lblConsultaCadastro.setBounds(106, 24, 205, 30);
		panel.add(lblConsultaCadastro);
		
		JButton btnNewButton = new JButton("Voltar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				TelaMenu b = new TelaMenu();
				b.mostrartela3();
			}
		});
		
		btnNewButton.setBounds(77, 136, 78, 23);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Editar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				Editar ed = new Editar();
				
				
			}
		});
		btnNewButton_1.setBounds(252, 136, 78, 23);
		panel.add(btnNewButton_1);
		
		lblNome = new JLabel("Nome: " + TelaLogin.nomeAtual);
		lblNome.setBounds(77, 65, 273, 14);
		panel.add(lblNome);
		
		lblSenha = new JLabel("Senha: " + TelaLogin.senhaAtual);
		lblSenha.setBounds(77, 101, 273, 14);
		panel.add(lblSenha);
		
		JButton btnNewButton_2 = new JButton("Excluir");
		
		btnNewButton_2.setBounds(164, 136, 78, 23);
		panel.add(btnNewButton_2);
		
		
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				ConfirmaExcluir ce = new ConfirmaExcluir();
			}
		});

		frame.setVisible(true);
		
	}
	
	
}
