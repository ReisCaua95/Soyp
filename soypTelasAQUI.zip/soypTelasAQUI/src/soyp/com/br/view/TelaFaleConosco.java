package soyp.com.br.view;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.SwingConstants;

import soyp.com.br.modelo.Mensagem;

import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.Font;

public class TelaFaleConosco {

	private JFrame frame;
	private JTextField nome;
	private JTextField email;
	private JTextField mensagem;

	
	public JTextField getNome() {
		return nome;
	}

	public JTextField getEmail() {
		return email;
	}

	public JTextField getMensagem() {
		return mensagem;
	}

	/**
	 * Launch the application.
	 */
	public void mostrartela6() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaFaleConosco window = new TelaFaleConosco();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public TelaFaleConosco() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 525, 417);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblFaleConosco = new JLabel("FALE CONOSCO");
		lblFaleConosco.setFont(new Font("Tempus Sans ITC", Font.PLAIN, 20));
		lblFaleConosco.setHorizontalAlignment(SwingConstants.CENTER);
		lblFaleConosco.setBounds(74, 28, 360, 23);
		panel.add(lblFaleConosco);
		
		JLabel lblNomeCompleto = new JLabel("Nome Completo:");
		lblNomeCompleto.setBounds(74, 62, 115, 14);
		panel.add(lblNomeCompleto);
		
		email = new JTextField();
		email.setLocation(74, 144);
		email.setSize(360, 20);
		email.setColumns(20);
		email.setText("Informe seu email");
		email.setSelectedTextColor(Color.GRAY);
		email.requestFocus();
		
		email.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
		((JTextField)e.getSource()).setText("");					
			}
		});
		
		nome = new JTextField();
		nome.setBounds(74, 84, 360, 20);
		nome.setColumns(20);
		nome.setText("Insira seu nome");
		nome.setSelectedTextColor(Color.GRAY);
		nome.requestFocus();
		
		nome.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
		((JTextField)e.getSource()).setText("");					
			}
		});
		
		panel.add(nome);
		
		JLabel lblEmail = new JLabel("E-mail:");
		lblEmail.setBounds(74, 120, 46, 14);
		panel.add(lblEmail);
		
		panel.add(email);
		
		mensagem = new JTextField();
		mensagem.setHorizontalAlignment(SwingConstants.LEFT);
		mensagem.setLocation(74, 191);
		mensagem.setSize(360, 76);
		mensagem.setColumns(20);
		mensagem.setText("Insira sua mensagem");
		mensagem.setSelectedTextColor(Color.GRAY);
		mensagem.requestFocus();
		
		mensagem.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
		((JTextField)e.getSource()).setText("");					
			}
		});
		
		JLabel lblMensagem = new JLabel("Mensagem:");
		lblMensagem.setBounds(74, 174, 101, 14);
		panel.add(lblMensagem);
		
		panel.add(mensagem);
		
		JButton enviar = new JButton("Enviar");
		enviar.setBounds(74, 278, 188, 23);
		panel.add(enviar);
		
		JLabel lblSoypgmail = new JLabel("soyp@gmail.com");
		lblSoypgmail.setHorizontalAlignment(SwingConstants.CENTER);
		lblSoypgmail.setBounds(72, 317, 117, 14);
		panel.add(lblSoypgmail);
		
		JLabel lblNewLabel = new JLabel("soypOficial");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(214, 317, 81, 14);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("(35) 99111-3871");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(333, 317, 101, 14);
		panel.add(lblNewLabel_1);
		
		JButton voltar = new JButton("Voltar");
		voltar.setBounds(272, 278, 76, 23);
		panel.add(voltar);
		
		JButton sair = new JButton("Sair");
		sair.setBounds(358, 278, 76, 23);
		panel.add(sair);
		
		voltar.addActionListener( new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				TelaMenu c = new TelaMenu();
				c.mostrartela3();
				
			}
		});
		
		
		sair.addActionListener( new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				TelaSair es = new TelaSair(6);
				es.mostrartela7(6);
				
			}
		});
		
        enviar.addActionListener( new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				if(nome.getText().length()>0 && email.getText().length()>0 && mensagem.getText().length()>0 &&
				   nome.getText().equals("Insira seu nome")==false && email.getText().equals("Informe seu email")==false && mensagem.getText().equals("Insira sua mensagem")==false) {
					frame.setVisible(false);
					Mensagem msg = new Mensagem(nome.getText(), email.getText(), mensagem.getText());
					ConfirmacaoForm es = new ConfirmacaoForm(msg);
					es.confirmacao(msg);
				}else {
					//if(nome.getText().equals("Insira seu nome") && email.getText().equals("Informe seu email") && mensagem.getText().equals("Insira sua mensagem")) {
						TelaErro erro = new TelaErro("Por favor preencha o formul�rio corretamente!");
						erro.mostrarErro("Por favor preencha o formul�rio corretamente!");	
					/*}else {
						if( nome.getText().equals("Insira seu nome") || nome.getText().length()==0 &&
							email.getText().length()>0 && mensagem.getText().length()>0 &&
							email.getText().equals("Informe seu email")==false && mensagem.getText().equals("Insira sua mensagem")==false) {
							TelaErro erro = new TelaErro("Por favor insira seu nome!");
							erro.mostrarErro("Por favor insira seu nome!");
						}else {
						
							if( email.getText().equals("Informe seu email") || email.getText().length()==0 &&
								nome.getText().equals("Insira seu nome")==false && mensagem.getText().equals("Insira sua mensagem")==false &&
								nome.getText().length()>0 && mensagem.getText().length()>0) {
								TelaErro erro = new TelaErro("Por favor insira seu email!");
								erro.mostrarErro("Por favor insira seu email!");
							}else {
								if( mensagem.getText().equals("Insira sua mensagem") || mensagem.getText().length()==0 &&
										nome.getText().equals("Insira seu nome")==false && email.getText().equals("Informe seu email")==false &&
										nome.getText().length()>0 && email.getText().length()>0) {
										TelaErro erro = new TelaErro("Por favor insira uma mensagem!");
										erro.mostrarErro("Por favor insira uma mensagem!");
								}else {
									TelaErro erro = new TelaErro("Por favor preencha o formul�rio corretamente!");
									erro.mostrarErro("Por favor preencha o formul�rio corretamente!");
								}
							}
						}
					}*/
				}
				
			}
		});

	}
}
