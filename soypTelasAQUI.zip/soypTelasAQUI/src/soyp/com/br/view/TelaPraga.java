package soyp.com.br.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JTextPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.LineBorder;

import soyp.com.br.controle.PanelPragaControle;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.UIManager;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JScrollPane;
import java.awt.GridLayout;

public class TelaPraga {
	private JFrame frame;
	private JPanel panel = new JPanel();
	
	private final JLabel lblCataogo = new JLabel("CAT\u00C1LOGO");

	
	public JPanel getPanel() {
		return panel;
	}


	/**
	 * Create the application.
	 */
	public TelaPraga() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(UIManager.getColor("Button.background"));
		frame.setBounds(100, 100, 577, 412);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new BorderLayout(0, 0));
		
		panel.setLayout(new GridLayout(0, 1, 0, 25));
		JScrollPane scrollPane = new JScrollPane(panel);
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		frame.getContentPane().add(scrollPane);
		lblCataogo.setHorizontalAlignment(SwingConstants.CENTER);
		lblCataogo.setFont(new Font("Tempus Sans ITC", Font.PLAIN, 20));
		frame.getContentPane().add(lblCataogo, BorderLayout.NORTH);
		
		JPanel panel_1 = new JPanel();
		frame.getContentPane().add(panel_1, BorderLayout.SOUTH);
		
				
				
				JButton voltar = new JButton("Voltar");
				panel_1.add(voltar);
				
				JButton sair = new JButton("Sair");
				panel_1.add(sair);
				
				sair.addActionListener( new ActionListener() {
					
					
					public void actionPerformed(ActionEvent e) {
						frame.setVisible(false);
						TelaSair es = new TelaSair(4);
						es.mostrartela7(4);
						
					}
				});
		
		voltar.addActionListener( new ActionListener() {
			
			
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				TelaMenu c = new TelaMenu();
				c.mostrartela3();
				
			}
		});
		
		frame.setVisible(true);
	}
	
	public void AdicionaPanelPraga(PanelPraga p) {
		panel.add(p.getPanel());
	}
	
}
