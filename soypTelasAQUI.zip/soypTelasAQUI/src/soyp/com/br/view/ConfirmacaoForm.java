package soyp.com.br.view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.border.LineBorder;

import soyp.com.br.modelo.Mensagem;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextPane;
import javax.swing.JButton;

public class ConfirmacaoForm {

	private JFrame frame;
	Mensagem msg;

	/**
	 * Launch the application.
	 */
	public  void confirmacao(Mensagem m) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ConfirmacaoForm window = new ConfirmacaoForm(m);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ConfirmacaoForm(Mensagem m) {
		this.msg=m;
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 625, 330);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel.setBounds(52, 38, 489, 182);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("SUA MENSAGEM FOI \r\nENVIADA COM SUCESSO!");
		lblNewLabel.setFont(new Font("Tempus Sans ITC", Font.PLAIN, 20));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(0, 11, 490, 27);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Mensagem: " + msg.getMensagem());
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1.setBounds(28, 106, 382, 14);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Nome: " + msg.getNome());
		lblNewLabel_2.setBounds(28, 56, 382, 14);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("E-mail: " + msg.getEmail());
		lblNewLabel_3.setBounds(29, 81, 381, 14);
		panel.add(lblNewLabel_3);
		
		JButton ok = new JButton("OK");
		ok.setBounds(28, 148, 122, 23);
		panel.add(ok);
		
		ok.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				TelaMenu tl3 = new TelaMenu();
				tl3.mostrartela3();
			}
		});
	}
}
