package soyp.com.br.view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.SwingConstants;

import soyp.com.br.dao.UsuarioBanco;

import javax.swing.JButton;

public class ConfirmaExcluir {

	private JFrame frame;

	

	/**
	 * Create the application.
	 */
	public ConfirmaExcluir() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 495, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblVocTemCerteza = new JLabel("Deseja excluir sua conta permanentemente?");
		lblVocTemCerteza.setHorizontalAlignment(SwingConstants.CENTER);
		lblVocTemCerteza.setFont(new Font("Tempus Sans ITC", Font.PLAIN, 24));
		lblVocTemCerteza.setBounds(0, 71, 479, 63);
		frame.getContentPane().add(lblVocTemCerteza);
		
		JButton btnSim = new JButton("Sim");
		btnSim.setBounds(114, 145, 112, 23);
		frame.getContentPane().add(btnSim);
		
		btnSim.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UsuarioBanco u = new UsuarioBanco();
				frame.setVisible(false);
				u.deletarUsuario();	
				
				
			}
		});
		
		JButton btnNo = new JButton("N\u00E3o");
		btnNo.setBounds(243, 145, 112, 23);
		frame.getContentPane().add(btnNo);
		
		btnNo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
				ConsultarCadastro cc = new ConsultarCadastro();
				
			}
		});
		frame.setVisible(true);
	}
}
