package soyp.com.br.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import Conexao.Conexao;
import soyp.com.br.modelo.Usuario;
import soyp.com.br.view.CadastroOK;
import soyp.com.br.view.ConsultarCadastro;
import soyp.com.br.view.CriarUsuario;
import soyp.com.br.view.TelaLogin;

public class UsuarioBanco {
	

		Conexao conexao = new Conexao();
		
		public void InsereUsuario(Usuario novo) {
			try {
				
				PreparedStatement ps= conexao.getConexao().prepareStatement(
						"insert into Usuario (nome, senha)" + 
						"values (?,?);");
	            
	            ps.setString(1, novo.getNome()); 
	            ps.setString(2, novo.getSenha());
	          
	            ps.executeUpdate();
	 	   	  
	 	   } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
	 	   }
			
		}
		
		//public ResultSet consultaUsuario() {
			//return consultaUsuario("");
		//}
		
		
		public ResultSet consultaUsuario() {
			ResultSet rs = null;
			
			
			try {
				Statement stmt= conexao.getConexao().createStatement();     
				rs = stmt.executeQuery("select * from Usuario");	


					/*while (rs.next()) {
						cc.getLblNomes().setText(rs.getString("nome") + "-" +rs.getString("senha"));
						
					}

				*/
					
					
					} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
	 	   }
			
			return rs;
		}
		
		public void atualizarUsuario(String nome, String senha) {
			try {
				PreparedStatement ps = conexao.getConexao().prepareStatement( "update USUARIO set nome = ?, senha = ? where id = ?;");  
				ps.setString(1, nome);
				ps.setString(2, senha);
				ps.setInt(3, TelaLogin.idAtual);
				ps.executeUpdate();
				System.out.println("O nome foi atualizado!! ");
			} catch(SQLException e)	{
				System.out.println("Seu nome n�o foi atualizado por algum motivo!");
				e.printStackTrace();
			}
		}
		
		
		public void deletarUsuario() {
			try {
				PreparedStatement ps = conexao.getConexao().prepareStatement( "DELETE from USUARIO where id = ?;");  
				ps.setInt(1, TelaLogin.idAtual);
				ps.executeUpdate();
				CadastroOK cok = new CadastroOK();
				cok.getLblCa().setText("Conta deletada com Sucesso!!");
				System.out.println("Conta exclu�da com Sucesso!! ");
			} catch(SQLException e)	{
				System.out.println("Sua conta n�o foi exclu�da por algum motivo!");
				e.printStackTrace();
			}
		}
		
		
		
		
		
		
	}



