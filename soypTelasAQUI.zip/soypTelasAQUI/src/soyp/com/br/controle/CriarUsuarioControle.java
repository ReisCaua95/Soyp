package soyp.com.br.controle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JPasswordField;
import javax.swing.JTextField;

import soyp.com.br.dao.UsuarioBanco;
import soyp.com.br.modelo.Usuario;
import soyp.com.br.view.CadastroOK;
import soyp.com.br.view.ConfirmacaoCadastro;
import soyp.com.br.view.CriarUsuario;
import soyp.com.br.view.TelaErro;
import soyp.com.br.view.TelaLogin;

public class CriarUsuarioControle {
	
	private CriarUsuario telaCriar;
	private Usuario usuario;
	
	public CriarUsuarioControle(CriarUsuario telaCriar) {
		this.telaCriar = telaCriar;
		
	}
		
	public void inicializaControle() {
		
		this.telaCriar.getBtnNewButton().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				telaCriar.getFrame().setVisible(false);
				TelaLogin c = new TelaLogin();
				c.main(null);
			}
		});
		
		this.telaCriar.getSenha().addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				((JPasswordField)e.getSource()).setText("");
				((JPasswordField)e.getSource()).setEchoChar('*');

			}
		});
		

		this.telaCriar.getNome().addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				((JTextField)e.getSource()).setText("");					
			}
		});
		
		
		this.telaCriar.getCsenha().addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				((JPasswordField)e.getSource()).setText("");
				((JPasswordField)e.getSource()).setEchoChar('*');

			}
		});
		
		
		
		this.telaCriar.getCriar().addActionListener(new ActionListener() {	
			public void actionPerformed(ActionEvent e) {
				if(telaCriar.getSenha().getText().equals(telaCriar.getCsenha().getText()) && telaCriar.getNome().getText().length()>0 && !telaCriar.getNome().getText().equals("Nome de usu�rio")) {
					telaCriar.getFrame().setVisible(false);
					Usuario u = new Usuario(telaCriar.getNome().getText(), telaCriar.getSenha().getText());
					
					
					UsuarioBanco usuarioBanco  = new UsuarioBanco();
					
					try {
						usuarioBanco.InsereUsuario(u);
						CadastroOK cok = new CadastroOK();
					} catch (Exception e1) {
						TelaErro erro = new TelaErro("Erro ao salvar no banco de dados!!!");
						erro.mostrarErro("Erro ao salvar no banco de dados!!!");						
					}
					
					
					 
					/*
					 * ConfirmacaoCadastro cf = new ConfirmacaoCadastro();
					 * ConfirmacaoCadastroControle ccc = new ConfirmacaoCadastroControle(u, cf);
					 * ccc.inicializaConfirmacaoCadastroControle();
					 */
					
				}else {
					if(telaCriar.getSenha().equals(telaCriar.getCsenha().getText()) == false && telaCriar.getNome().getText().length()>0 && !telaCriar.getNome().getText().equals("Nome de usu�rio")) {
						TelaErro erro = new TelaErro("As senhas n�o s�o coincidentes ou n�o foram inseridas!");
						erro.mostrarErro("As senhas n�o s�o coincidentes ou n�o foram inseridas!");
					}else if(telaCriar.getSenha().equals(telaCriar.getCsenha().getText()) && telaCriar.getSenha().getText().length()>0 && telaCriar.getCsenha().getText().length()>0 && telaCriar.getNome().getText().length()==0) {
							TelaErro erro = new TelaErro("O nome n�o foi inserido!");
							erro.mostrarErro("O nome n�o foi inserido!");
						}else {
							TelaErro erro = new TelaErro("O nome n�o foi inserido ou as senhas n�o s�o coincidentes!");
							erro.mostrarErro("O nome n�o foi inserido ou as senhas n�o s�o coincidentes!");
						}
					}				
			}
		});
		
		
	}
	
}