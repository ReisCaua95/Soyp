package soyp.com.br.controle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import soyp.com.br.modelo.Usuario;
import soyp.com.br.view.ConfirmacaoCadastro;
import soyp.com.br.view.CriarUsuario;
import soyp.com.br.view.TelaMenu;

public class ConfirmacaoCadastroControle {
	private Usuario usuario;
	private ConfirmacaoCadastro confirmar;
	
	
	public ConfirmacaoCadastroControle(Usuario usuario, ConfirmacaoCadastro confirmar) {
		this.usuario = usuario;
		this.confirmar = confirmar;
	}
	
	public void inicializaConfirmacaoCadastroControle() {
		atualizaDados();
		abreTelaConfirmarCadastro();
		
		this.confirmar.getOk().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				confirmar.getFrame().setVisible(false);
				TelaMenu tl3 = new TelaMenu();
				tl3.mostrartela3();
			}
		});
		
		this.confirmar.getBtnEditar().addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				confirmar.getFrame().setVisible(false);
				CriarUsuario a = new CriarUsuario();
				a.mostrartela2();
				a.getNome().setText(usuario.getNome());
				a.getSenha().setText(usuario.getSenha());
				a.getSenha().setEchoChar('*');
				a.getCsenha().setText(usuario.getSenha());	
				a.getCsenha().setEchoChar('*');
			}
		});
		
		

	}
	
	public void atualizaDados() {
		this.confirmar.getNomeL().setText("Nome: " + this.usuario.getNome());
		this.confirmar.getSenhaL().setText("Senha: " + this.usuario.getSenha());
	}
	
	public void abreTelaConfirmarCadastro() {
		confirmar.confimar();
	}
	
	
	
}
