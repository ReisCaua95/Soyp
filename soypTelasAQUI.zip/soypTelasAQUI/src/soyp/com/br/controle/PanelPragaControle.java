package soyp.com.br.controle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;

import soyp.com.br.modelo.Praga;
import soyp.com.br.view.PanelPraga;
import soyp.com.br.view.TelaPraga;

public class PanelPragaControle {
	private Praga praga;
	private PanelPraga panel;
	
	public PanelPragaControle(Praga praga, PanelPraga panel) {
		this.praga = praga;
		this.panel = panel;
	}
	
	public void inicializaControle() {
		configuraLabels();
		inicializaListeners();
	}
	
	private void inicializaListeners() {
		this.panel.getMaisBtn().addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				//abrir uma nova janela com infos da praga
					// pegar dados da praga
					///criar objeto da tela das infos da praga
					// inicializar
			}
		});
		
	}

	private void configuraLabels() {
		this.panel.getNomeComum().setText("Nome comum: " + this.praga.getNomeComum());
		this.panel.getNomeCientifico().setText("Nome cientifico: " + this.praga.getNomeCientifico());
		this.panel.getLocalDeAtaque().setText("Local de ataque: " + this.praga.getLocalAtaque());
		this.panel.getFoto().setIcon(new ImageIcon(praga.getCaminhoFoto()));
	}
	
	
}
