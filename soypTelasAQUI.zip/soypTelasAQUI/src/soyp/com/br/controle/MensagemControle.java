package soyp.com.br.controle;

import soyp.com.br.modelo.Mensagem;
import soyp.com.br.view.TelaFaleConosco;

public class MensagemControle {
	private Mensagem mensagem;
	private TelaFaleConosco telafaleConosco; 
	
	public void inicializaControle() {
		
	}
	

	
}
