package soyp.com.br.controle;

import java.awt.Component;

import soyp.com.br.view.PanelPraga;
import soyp.com.br.view.TelaPraga;

public class PanelTelaPragaControle {
		private PanelPraga panel;
		private TelaPraga tela;
		
		
		public PanelTelaPragaControle(PanelPraga panel, TelaPraga tela) {
			this.panel = panel;
			this.tela = tela;
		}
		
		public void inicializaControle() {
			adicionaPanelTelaPraga();
			
		}
		
		
		public void adicionaPanelTelaPraga() {
			this.tela.getPanel().add(this.panel.getPanel());
			
		}		
		
}
