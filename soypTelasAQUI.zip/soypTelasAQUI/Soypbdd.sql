create database Soyp;
use Soyp;

create table Usuario(
id int not null auto_increment,
nome varchar(100),
senha varchar(30),
primary key(id)
)Engine Innodb;

