<?php 
  
  class Usuario{
    private $nome;
    private $email;

    public function getNome(){ return $this->nome;}
    public function getEmail(){ return $this->email;}

    public function setNome($nome){ $this->nome=$nome;}
    public function setEmail($email){ $this->email=$email;}

    function __construct($nome, $email){
      $this->setNome($nome);
      $this->setEmail($email);
    }
  }

  
  class Mensagem{
    private $assunto;
    private $msg;

    public function getAssunto(){ return $this->assunto;}
    public function getMsg(){ return $this->msg;}

    public function setAssunto($assunto){ $this->assunto=$assunto;}
    public function setMsg($msg){ $this->msg=$msg;}

    function __construct($assunto, $msg)    {
      $this->setAssunto($assunto);
      $this->setMsg($msg);
    }
  }


  class Avaliacao{
    private $opiniao;
    private $divulgacao;
    
    public function getOpiniao(){return $this->opiniao;}
    public function getDivulgacao(){return $this->divulgacao;}

    public function setOpiniao($opiniao){$this->opiniao=$opiniao;}
    public function setDivulgacao($divulgacao){$this->divulgacao=$divulgacao;}

    function __construct($opiniao, $divulgacao){
      $this->setOpiniao($opiniao);
      $this->setDivulgacao($divulgacao);
    }
  }

  

  $erro = "";
  if(isset($_POST['nome']) && strlen($_POST['nome'])>0 &&
     isset($_POST['email']) && strlen($_POST['email'])>0 && strstr($_POST['email'], "@") && strstr($_POST['email'], ".com") &&
     isset($_POST['motivo']) && $_POST['motivo']>0 &&
     isset($_POST['mensagem']) && strlen($_POST['mensagem'])>0 &&
     isset($_POST['radio']) && strlen($_POST['radio'])>0 &&
     isset($_POST['divulgacao']) && count($_POST['divulgacao'])>0
   ){
        $nome = $_POST['nome'];
        $email = $_POST['email'];
        $msg = $_POST['mensagem'];
        $opiniao = $_POST['radio'];
        $divulgacao = $_POST['divulgacao'];

        switch ( $_POST['motivo']) {
          case '1':
            $assunto = "Cadastro de nova praga";
            break;

          case '2':
            $assunto = "Parcerias";
            break;
          
          case '3':
            $assunto = "Conhecer mais do projeto";
            break;

          case '4':
            $assunto = "Conhecer melhor o aplicativo";
            break;

          case '5':
            $assunto = "Dúvidas";
            break;

          case '6':
            $assunto = "Sugestões";
            break;

          case '7':
            $assunto = $_POST['outro'];
            break;
        }

        $usuario = new Usuario($nome, $email);
        $mensagem = new Mensagem($assunto, $msg);
        $avaliacao = new Avaliacao($opiniao, $divulgacao);


  }else{
    if (!isset($_POST['nome']) || strlen($_POST['nome'])<=0) {
      $erro = $erro . "Nome não foi informado! <br>";
    }

    if (!isset($_POST['email']) || strlen($_POST['email'])<=0 || !strstr($_POST['email'], "@") || !strstr($_POST['email'], ".com")) {
      $erro = $erro . "Email inválido! <br>";
    }

    if (!isset($_POST['motivo']) || strlen($_POST['motivo'])<=0) {
      $erro = $erro . "O assunto da mensagem não foi declarado! <br>";
    }

    if (!isset($_POST['mensagem']) || strlen($_POST['mensagem'])<=0) {
      $erro = $erro . "Nenhuma mensagem foi inserida! <br>";
    }

    if (!isset($_POST['radio']) || strlen($_POST['radio'])<=0) {
      $erro = $erro . "Por favor, avalie nosso projeto! <br>";
    }

    if (!isset($_POST['divulgacao']) || count($_POST['divulgacao'])<=0) {
      $erro = $erro . "Por favor, nos diga como você ficou sabendo do nosso projeto! <br>";
    }

  }


?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    
    <title>SOYP - Identificador de Pragas de Soja</title>

    <!-- Font Awesome Icons -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Merriweather+Sans:400,700" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>

    <!-- Plugin CSS -->
    <link href="vendor/magnific-popup/magnific-popup.css" rel="stylesheet">

    <!-- Theme CSS - Includes Bootstrap -->
    <link href="css/creative.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/creative.css">

    <!-- MEU CSS -->
    <link rel="stylesheet" type="text/css" href="css/estilo.css">

    <!-- COLOCANDO O LOGO NA GUIA -->
    <link rel="shortcut icon" href="img/logo2.png" type="image/x-png"/>

    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script src = "fancybox-master/fancybox-master/dist/jquery.fancybox.min.js"> </script>

    <!-- MEU JQUERY-->
    <script type="text/javascript" src="js/vl.js"></script>

</head>

<body id="page-top">

  <!-- MENU -->
  <nav class="navbar navbar-expand-lg navbar-light fixed-top py-3" id="mainNav">

      <div class="container">
          <a class="navbar-brand js-scroll-trigger fechar" href="#page-top">SOYP</a>
        
          <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>

          <div class="collapse navbar-collapse" id="navbarResponsive">
              <ul class="navbar-nav ml-auto my-2 my-lg-0">

                  <li class="nav-item">
                    <a class="nav-link js-scroll-trigger" href="#app">Aplicativo</a>
                  </li>

                  <li class="nav-item">
                    <a class="nav-link js-scroll-trigger" href="#services">Soja</a>
                  </li>

                  <li class="nav-item">
                    <a class="nav-link js-scroll-trigger" href="#portfolio">Catálogo de Pragas</a>
                  </li>

                  <li class="nav-item">
                    <a class="nav-link js-scroll-trigger" href="#contact">Contatos</a>
                  </li>
                  
                  <li class="nav-item">
                    <a class="nav-link js-scroll-trigger" href="#desenvolvedores">Desenvolvedores</a>
                  </li>

              </ul>
          </div>
      </div>
  </nav>

  <!-- Masthead -->
  <header class="masthead">
      <div class="container h-100">
          <div class="row h-100 align-items-center justify-content-center text-center">

                <div class="col-lg-10 align-self-end">
                    <h1 class="text-uppercase text-white font-weight-bold">Reconhecendo pragas de forma rápida e fácil</h1>
                    <hr class="divider my-4">
                </div>

                <div class="col-lg-8 align-self-baseline">
                    <p class="text-white-75 font-weight-light mb-5">Aqui você descobrirá a importância econômica da soja, sua história, utilizações e benefícios para saúde, e também poderá acessar um catálogo de pragas, recheado com informações e imagens. Não deixe de agilizar seu trabalho utilizando nosso aplicativo de reconhecimento!</p>
                    <a class="btn btn-success btn-xl js-scroll-trigger" href="#about">Saiba mais sobre nosso projeto!</a>
                </div>

          </div>
      </div>
  </header>

  <!-- SEÇÃO 1  -->
  <section class="page-section bg-success" id="about">
      <div class="container">
          <div class="row justify-content-center">
              <div class="col-lg-8 text-center">
                <h2 class="text-white mt-0"> Quem somos?</h2>
                <hr class="divider light my-4">
                <p class="text-white-50 mb-4 text-justify"> 
                  O Soyp ("soy", do inglês, significa "soja" e a letra "p" faz referência a "pests", que significa pragas) é um projeto iniciado em 2018, que tem o objetivo de inovar os processos de reconhecimento de pragas através da aplicação de Redes Neurais Artificiais em um aplicativo de identificação <i>mobile</i>. 
                </p>

                <p class="text-white-50 mb-4 text-justify"> 
                  No ano de 2018 seu foco foi em realizar uma pesquisa exploratória, a fim de construir uma base científica para o projeto, dessa forma seu trabalho consistiu em buscar informações sobre a importância da soja no Brasil, suas utilizações, história, morfologia e as pragas que atacam este tipo de cultivo. Após este estudo, a construção deste site informativo foi inciada. 
                </p>

                <p class="text-white-50 mb-4 text-justify"> 
                  Agora, em 2019, o foco do projeto está sendo em trazer melhorias de usabilidade ao site e em estudar e realizar o treinamento da rede neural artificial. Sendo assim, até este momento, foi escolhida uma praga como "cobaia" para posar para as fotografias que servirão de entradas para o treinamento da RNA. Neste ano, o projeto também pretende desenvolver um protótipo de como será o aplicativo de reconhecimento.

                  O Soyp é desenvolvido por Cauã Reis Gonçalves, Mariana de Siqueira Silva e Raiane Esheley Moreno de Oliveira, alunos do 3º ano do Ensino Médio integrado a informática do IFSP - Campus Bragança Paulista, sob orientação da Pr. Dr. Cristina Corrêa de Oliveira. 
                  
                  </p>
                
                  <br>
                  <a class="btn btn-light btn-xl js-scroll-trigger" href="#app">Conheça mais nosso aplicativo!</a>
              </div>
          </div>
      </div>
  </section>

  <!-- Call to Action Section -->
  <section class="page-section bg-dark" id="app">
      <div class="container">
          <div class="row justify-content-center">
              <div class="col-lg-8 text-center">
                <h2 class="text-white mt-0">Você já pensou em reconhecer uma praga praticamente em tempo real, sem precisar ser especialista no assunto?</h2>
                <hr class="divider bg-success my-4">
                <p class="text-white-50 mb-4 text-justify">Pois bem, com o aplicativo SOYP isso será possível! Nosso projeto busca desenvolver um aplicativo para celular, capaz de reconhecer uma praga atráves do uso de imagens, ou seja, basta você tirar uma foto do bicho, que imediatamente saberá que praga que você fotografou. Nosso aplicativo utiliza de técnicas de redes neurais no reconhecimento de imagens, além de fazer a identificação, ele registrará a localização da praga fotografada, permitindo delimitar as áreas atacadas de sua plantação. Nosso objetivo também inclui informar as pessoas sobre os benefícios da soja, sua história, morfologia, importância econômica e muito mais!</p>

                <div class="embed-responsive embed-responsive-16by9">
                    <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/Q-iXHXKgzrc" allowfullscreen></iframe>
                </div>

                <br><br>
                <a class="btn btn-light btn-xl js-scroll-trigger" href="#">Ver mais informações!</a>
              </div>
          </div>
      </div>
  </section>




  <!-- SEÇÃO 2 -->
  <section class="page-section" id="services">
      <div class="container">
            <h2 class="text-center mt-0">Desvendando o mundo da soja!</h2>
            <hr class="divider my-4">

            <div class="row" >

                  <div class="col-lg-3 col-md-3  col-sm-3 col-6 text-center">
            	        <div class="mt-5">
              	          	<a href="" class="sojalink js-scroll-trigger" data-toggle="modal" data-target="#Mhistoria">
              	            	  <i class="fas fa-4x fa-scroll text-success mb-4"></i>
              	            	  <h3 class="h4 mb-2">História</h3>
                                <p class="text-muted mb-0"> A história da soja é um tanto enigmática, pois...</p>
              	            </a>
            	        </div>

                    


                      <!-- Modal -->
                      <div class="modal fade" id="Mhistoria" tabindex="-1" role="dialog" aria-labelledby="TituloModalLongoExemplo" aria-hidden="true">
                        <div class="modal-dialog modal-xl" role="document">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h2 class="modal-title" id="TituloModalLongoExemplo">A História da Soja</h2>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="modal-body text-justify">
                              <p>A história da soja é um tanto enigmática, pois não se sabe ao certo quais são suas origens. Muitos autores discordam sobre o local exato de seu surgimento, porém todos indicam que este teria ocorrido no leste da Ásia. Escritos antigos da China relatam que a soja, já fazia parte da alimentação das pessoas, há centenas de anos antes de seus primeiros registros de cultivo. O registro mais antigo, presente no ervário Pen Ts’ao Kang Mu, tem data de 2838 a.C. e recomendações a respeito de como realizar a colheita, qual o melhor solo para o plantio, diferentes espécies e utilizações datam desde 2207 a.C. Em virtude disto, pode-se dizer que a soja seria uma das espécies mais antigas que o homem já cultivou.</p>

                              <br>

                              
                              <h4>No Brasil</h4>
                              <hr/>
                              <p >Em 2018 a sojicultura completa 136 anos de existência no Brasil. O primeiro registro sobre soja em solos brasileiros ocorreu na Bahia em 1882. Gustavo D’utra foi o responsável por relatar os diversos testes, com diferentes espécies, que foram realizados em vários pontos do país, como na cidade de Campinas no estado de São Paulo na Estação Agronômica de Campinas, atual Instituto Agronômico de Campinas. </p>

                              <p >Com o objetivo de impulsionar o cultivo de soja no Brasil, em 1900, a Secretaria de Agricultura, Comércio e Obras Públicas do Estado de São Paulo distribuiu sementes para 70 pessoas. Os resultados obtidos por meio dessa estratégia foram excelentes e contribuíram para disseminar a planta para outras regiões do país. </p>

                              <p>Em 1908 no estado de São Paulo, imigrantes japoneses começam a plantar soja para sua própria alimentação, intensificando ainda mais o cultivo da oleaginosa. Além disso, um dos incentivadores da cultura, Henrique Lóbbe, trouxe 48 espécies dos Estados Unidos para serem plantadas no Brasil, o que impulsionou os estudos a respeito da planta. </p>

                              <p >A soja chega ao Rio Grande do Sul, através da Universidade Federal de Pelotas que distribuiu sementes na região, onde finalmente ela conseguiu se adaptar bem, proporcionando ao estado, em 1941, o primeiro registro oficial de estatística e a construção da primeira fábrica de processamento de soja. São Paulo só teve seu primeiro registro oficial em 1945 e apenas em 1949 que o Brasil aparece como produtor de soja nas estatísticas internacionais.</p>

                              <p>A partir 1950, muitos agricultores emigraram do sul do país para a região central do Brasil, como Mato Grosso do Sul, Goiás e Mato Grosso, povoando e valorizando o cerrado, que antes era ocupado pela pecuária.</p>

                              <p>No Brasil, o plantio de soja tem crescido muito, chegando a abranger lugares no norte e nordeste do país como a região do MAPITOBA (Maranhão, Piauí, Tocantins e Bahia). Tal expansão é decorrente dos avanços científicos e tecnológicos ligados ao setor produtivo brasileiro, como pacotes tecnológicos de manejo de solo, adubo, calagem, pragas, doenças, além da identificação. Esses avanços fazem com que a soja se adapte em regiões com condições não tão favoráveis a ela e são desenvolvidos com o objetivo de solucionar as perdas na colheita. </p>

                              <p>Estudos apontam que, além de possuir tecnologias que permitem a adaptação da planta a lugares edafoclimáticamente desfavoráveis, o Brasil possui territórios para onde possa ampliar a área plantada, o que dá ao país um acréscimo de 40% em capacidade produtiva da commodity, possibilitando que ele ultrapasse os Estados Unidos, assumindo o lugar de maior produtor mundial de soja até 2020.</p>

                              <div class="col-md-12 text-center">
                                <figure>
                                    <img src="img/mapitoba1.jpg" class="img-fluid">
                                    <figcaption>Região do Mapitoba</figcaption>
                                  
                                </figure>
                              </div>  

                              <br>

                              <h4>Distribuição espacial da soja nos biomas brasileiros ao longo dos anos  </h4>
                              <hr/>
                              <figure class="text-center">
                                  <img src="img/mapa1.png" class="img-fluid">
                                  <img src="img/mapa2.png" class="img-fluid">
                                  <figcaption>(FONTE: IBGE)</figcaption>
                              </figure>


                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-success" data-dismiss="modal">Fechar</button>
                              
                            </div>
                          </div>
                        </div>
                      </div>

                  </div>

                  <div class="col-lg-3 col-md-3 col-sm-3 col-6 text-center">
                      <div class="mt-5">
                          	<a href="" class="sojalink js-scroll-trigger" data-toggle="modal" data-target="#MEconomia">
                          		  <i class="fas fa-4x fa-dollar-sign text-success mb-4"></i>
                            	  <h3 class="h4 mb-2">Economia</h3>
                                <p class="text-muted mb-0">O Brasil é o 2º maior produtor de soja do mundo...</p>
                            </a>
                      </div>


                      <!-- Modal -->
                      <div class="modal fade" id="MEconomia" tabindex="-1" role="dialog" aria-labelledby="TituloModalLongoExemplo" aria-hidden="true">
                        <div class="modal-dialog modal-xl" role="document">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h2 class="modal-title" id="TituloModalLongoExemplo">A importância Economia da Soja</h2>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="modal-body text-justify">
                              <p>O Brasil é o segundo maior produtor de soja do mundo. Como visto no tópico História da Soja, com o decorrer dos anos a soja foi se espalhando pelo Brasil, chegando a alcançar regiões de cerrado e no norte e nordeste do país. Isso ocorreu, devido aos avanços tecnológicos, que permitiram que a soja se adaptasse as diversas condições edafoclimáticas do solo brasileiro. Estudos apontam que além de possuir tais tecnologias, o Brasil possui muitos territórios para onde possa expandir o plantio da oleaginosa, possibilitando que o país ultrapasse, em breve, o maior produtor mundial de soja, os Estados Unidos.</p>

                                <p >A soja é uma das bases que movimentam a economia brasileira e nos últimos anos tem apresentado um crescimento continuo da área plantada. Segundo a Conab (Companhia Nacional de Abastecimento) a área plantada de soja no Brasil na safra de 2012/2013 era de aproximadamente 27 milhões de hectares, já na ultima safra de 2017/2018 esse número aumentou em cerca de 8 milhões de hectares, atingindo uma área plantada de 35,150 milhões de hectares. Durante o período analisado, de 2012 a 2018, a área planta apresentou constante aumento, como pode ser visto no gráfico 1, o que mostra o quanto o mercado da soja tem crescido e se tornado uma importante produção no país.</p>
                               
                                <br>
                                <figure class="text-center">
                                      <img src="img/areaPlantada.png" class="img-fluid">
                                      <figcaption>Gráfico 1: Área plantada de soja no Brasil em mil hectares (Fonte: Conab)</figcaption>
                                </figure>

                                <br><br>

                                <p >Junto com a área plantada, aumentou a produção de soja no Brasil. Na safra de 2012/2013 foram produzidas cerca de 81 milhões de toneladas de soja, ao decorrer dos anos esse número aumentou atingindo na safra de 2015/2016 a casa dos 100 milhões de toneladas. Na última safra de 2017/2018 a produção chegou a aproximadamente 117 milhões de toneladas, um aumento de cerca de 36 milhões de toneladas, quando comparado à safra de 2012/2013 (Gráfico 2).</p>

                                <br>

                                <figure class="text-center">
                                    <img src="img/producaoSoja.png" class="img-fluid">
                                    <figcaption>Gráfico 2: Produção de soja no Brasil em mil toneladas (Fonte: Conab)</figcaption>
                                </figure>
                                
                                <br><br>

                                <p>Dessa forma, torna-se notório o quanto o agronegócio de soja tem crescido e se tornado importante para a economia brasileira nos últimos anos. Todos os fatores que possam prejudicar as plantações de soja devem ser levados em conta, pois as perdas no plantio podem significar grandes prejuízos econômicos.</p>

                                <p>As perdas nas plantações podem ser decorrentes de fatores abióticos, bióticos e até mesmo econômicos. Os fatores abióticos são principalmente os relacionados ao clima, que dependendo das condições podem destruir lavouras, tardar colheitas e atrapalhar a germinação das sementes. Os bióticos referenciam-se as doenças e as pragas que atacam as plantações e os econômicos ocorrem, por exemplo, quando no momento da colheita o preço do produto abaixa, levando o agricultor, muitas vezes, a destruir sua plantação. Outros agentes como o preparo do solo, qualidade das sementes, momento da semeadura e escolha da variedade influenciam nos índices de perdas tanto na pré-colheita, quanto na colheita.</p>

                                <p>Para evitar perdas no cultivo e consequentemente prejuízos econômicos, estudos sobre como controlar esses fatores, são essenciais. Portanto o SOYP é um software extremamente importante, pois busca auxiliar o agricultor no controle sobre os fatores bióticos, especificamente as pragas, e proporcionar um maior controle sobre a área da plantação que está sendo danificada, contribuindo assim para a melhoria desse quadro econômico.</p>
                                <br>
                                
                                <figure class="text-center">
                                    <img src="img/eco2.jpg" class="img-fluid">
                                    <figcaption>Plantação de soja</figcaption>
                                </figure>
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-success" data-dismiss="modal">Fechar</button>
                              
                            </div>
                          </div>
                        </div>
                      </div>
                  </div>

                  <div class="col-lg-3 col-md-3 col-sm-3 col-6 text-center">
                      <div class="mt-5">
                          	<a href="" class="sojalink js-scroll-trigger" data-toggle="modal" data-target="#MUtilizacao">
                            	  <i class="fas fa-4x  fa-cheese text-success mb-4"></i>
                            	  <h3 class="h4 mb-2">Utilizações</h3>
                                <p class="text-muted mb-0">A soja está presente no cotidiano das pessoas...</p>
                            </a>
                      </div>



                      <!-- Modal -->
                      <div class="modal fade" id="MUtilizacao" tabindex="-1" role="dialog" aria-labelledby="TituloModalLongoExemplo" aria-hidden="true">
                        <div class="modal-dialog modal-xl" role="document">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h2 class="modal-title" id="TituloModalLongoExemplo">Utilizações da Soja no Cotidiano</h2>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="modal-body text-justify">
                              <p>Anteriormente, as utilizações da soja mais conhecidas, eram obtidas através da extração de seu óleo vegetal, seguido de seu subproduto, o farelo da soja.</p>

                              <p>Entretanto, a população oriental detinha grande conhecimento sobre tal leguminosa e passa a criar novas formas de utilizar os seus grãos.</p>

                              <p>Atualmente os grãos da soja também podem ser utilizados para a produção de leite de soja, missô (massa de soja cozida), tofu (queijo feito com soja), molho de soja (liquido obtido pela fermentação dos grãos de soja), farinha de soja e podem ser ingeridos, assados ou tostados.</p>

                              <p>O seu óleo vegetal, é rico em ácidos graxos (84,15%). No âmbito alimentício é utilizado, normalmente, como óleo de salada, fritura e na produção de manteiga ou margarina. Além disso, possui aplicações industriais, como o biodiesel, tintas de canetas, xampus, detergentes e sabões.</p>

                              <p>O farelo de soja, comumente, é empregado como suplemento protéico para os animais, como o gado, aves domésticas e suínos. Além de que, serve como substituto do leite para os bezerros e é usado como alimento de alguns tipos de peixes.</p>

                              <p>Já a farinha de soja, é utilizada na fabricação de rações de animais. No âmbito alimentar é empregada na produção de massas, cereais, carne de soja, biscoitos, pães, entre outros. Ademais atua como um grande auxiliar nos processos de fermentação</p>
                            

                              <div class="text-center">
                                <div class="row">
                                  <div class="col-md-6">
                                    <figure >
                                        <img src="img/utilizacoesSoja22.jpg" class="img-fluid">
                                        <figcaption>Grãos de soja e vagens</figcaption>
                                        
                                    </figure>
                                  </div>
                              

                                  <div class="col-md-6">
                                    <figure >
                                          <img src="img/utilizacoesSoja3.jpg" class="img-fluid">
                                          <figcaption>Leite e farelo de soja</figcaption>
                                    </figure>
                                  </div>

                                  <div class="col-md-12">
                                    <figure >
                                          <img src="img/utilizacoesSoja44.jpg" class="img-fluid">
                                          <figcaption>Óleo de soja, shoyu e carne de soja</figcaption>
                                    </figure>
                                  </div>
                                </div>
                              </div>
                              
                            
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-success" data-dismiss="modal">Fechar</button>
                            </div>
                          </div>
                        </div>
                      </div>
                  </div>

                  <div class="col-lg-3 col-md-3 col-sm-3 col-6 text-center" id="services2">
                      <div class="mt-5">
                          	<a href="" class="sojalink js-scroll-trigger" data-toggle="modal" data-target="#ModalLongoExemplo">
                              	<i class="fas fa-4x text-success fa-leaf mb-4"></i>
                              	<h3 class="h4 mb-2">Morfologia</h3>
                                <p class="text-muted mb-0">No Brasil, a soja habitualmente cultivada para a obtenção...</p>
                            </a>
                      </div>



                      <!-- Modal -->
                      <div class="modal fade" id="ModalLongoExemplo" tabindex="-1" role="dialog" aria-labelledby="TituloModalLongoExemplo" aria-hidden="true">
                        <div class="modal-dialog modal-xl" role="document">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h2 class="modal-title" id="TituloModalLongoExemplo">Morfologia da Soja</h2>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="modal-body text-justify">
                              <p> No Brasil, a soja habitualmente cultivada para a obtenção de grãos é a Glycine max, que faz parte do grupo das angiospermas e classifica-se como uma eudicotiledônea.</p>

                              <p>Seu caule é híspido (coberto de pelos) e têm poucas ramificações, a raiz é pivotante (possui um eixo principal desenvolvido) e bastante ramificada, suas folhas são trifolioladas (exceto no primeiro par do nó acima do nó cotiledonar).</p>

                              <p> Suas flores são roxas, brancas ou intermediárias e possuem caráter autógamo (hermafroditas que se autopolinizam), o que é típico da subfamília Papileonoideae.</p>

                              <p>Desenvolvem vagens que conforme amadurecem mudam da cor verde para amarelo-pálido, marrom, cinza ou marrom-claro, e possuem entre uma e cinco sementes lisas e globosas, com tegumento (revestimento externo da semente) amarelo pálido e com hilo preto, marrom, ou amarelo-palha. </p>

                              <p>Sua altura ideal é de 60cm a 110cm (Embrapa-CNPSo, 2008).</p>

                              <div class="row">
                                  <div class="col-md-4">
                                    <figure class="text-center">
                                          <img src="img/morfologia22.jpg" class="img-fluid">
                                          <figcaption>A soja</figcaption>
                                    </figure>
                                  </div>
                                    
                                  <div class="col-md-4">
                                    <figure class="text-center">
                                          <img src="img/morfologia44.png" class="img-fluid">
                                          <figcaption>A soja</figcaption>
                                    </figure>
                                  </div>

                                  <div class="col-md-4">
                                    <figure class="text-center">
                                          <img src="img/morfologia77.jpg" class="img-fluid">
                                          <figcaption>Vagem da soja madura</figcaption>
                                    </figure>

                                  </div>
                              </div>

                              <div class="row">  
                                  <div class="col-md-6">
                                    <figure class="text-center">
                                          <img src="img/morfologia33.jpg" class="img-fluid">
                                          <figcaption>Vagem da soja verde</figcaption>
                                          
                                    </figure>
                                  </div>

                                  <div class="col-md-6">
                                    <figure class="text-center">
                                          <img src="img/morfologia55.jpg" class="img-fluid">
                                          <figcaption>A flor da soja</figcaption>
                                    </figure>
                                  </div> 
                              </div>      
                            </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-success" data-dismiss="modal">Fechar</button>
                            </div>
                          </div>
                        </div>
                      </div>

                  </div >

            </div>
      </div >    
     
  </section>

 
      
  <section id="#">
    <div class="container-fluid p-0">
        <div class="row no-gutters">


          <!-- Botão para acionar modal -->
          <div class="col-lg-4 col-sm-6" >

                      <a href="" data-toggle="modal" data-target="#lagarta">
                          <img class="img-fluid" src="img/portfolio/thumbnails/1.jpeg" alt="">
                      </a>
          </div>
    

            <!-- Modal -->
          <div class="modal fade" id="lagarta" tabindex="-1" role="dialog" aria-labelledby="TituloModalLongoExemplo" aria-hidden="true">
            <div class="modal-dialog modal-xl" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h2 class="modal-title" id="TituloModalLongoExemplo">Lagarta da Soja <i>(Anticarsia gemmatalis)</i></h2>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Fechar">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                  <div class="container">
                        <div class="row">
                          <p class="text-justify">
                            A lagarta consome os folíolos novos, mais tenros. Em condições favoráveis, este inseto pode causar desfolha total em áreas extensas. Ocasionalmente, a densidade pode atingir mais de 200 lagartas por pano de batida, mas densidades desta magnitude não são comuns. Na parte central da Argentina esta lagarta pode ser encontrada alimentando-se de vagens da soja.
                          </p>
                        </div>
                        <div class="row">

                        
                        <div class="offset-2 col-8">
                          <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">

                              <ol class="carousel-indicators">
                                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                                <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                                <li data-target="#carouselExampleIndicators" data-slide-to="3"></li>
                              </ol>

                              <div class="carousel-inner">

                                <div class="carousel-item active">
                                  <img class="d-block w-100 img-fluid" src="img/lagarta2.jpg" alt="Primeiro Slide">
                                </div>

                                <div class="carousel-item">
                                  <img class="d-block w-100 img-fluid" src="img/lagarta1.gif" alt="Segundo Slide">
                                </div>

                                <div class="carousel-item">
                                  <img class="d-block w-100 img-fluid" src="img/mariposa.jpeg" alt="Terceiro Slide">
                                </div>

                                <div class="carousel-item">
                                  <img class="d-block w-100 img-fluid" src="img/mariposa2.jpg" alt="Terceiro Slide">
                                </div>

                              </div>

                              <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="sr-only">Anterior</span>
                              </a>

                              <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="sr-only">Próximo</span>
                              </a>
                          </div>
                        </div>
                      
                  </div>
                  <br><br>
                    <div class="row">
                      <div class="col-12">
                      <div class="card">
                          <div class="card-header">
                            <h5><strong>Informações:</strong></h5>
                          </div>
                          <ul class="list-group list-group-flush">
                            <li class="list-group-item"><strong>Nome cientifíco:</strong> <i>Anticarsia gemmatalis</i></li>
                            <li class="list-group-item"><strong>Tamanho Lagarta:</strong> variável, podem ter 10mm ou serem maiores que 15mm.</li>
                            <li class="list-group-item"><strong>Coloração da Lagarta:</strong> verde</li>
                          </ul>
                      </div></div>
                    </div>

                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-success" data-dismiss="modal">Fechar</button>
                </div>
              </div>
            </div>
          </div>
      </div>
    </div>

 

  <!-- Portfolio Section 
  <section id="portfolio">

    <div class="container-fluid p-0">
        <div class="row no-gutters">

            <div class="col-lg-4 col-sm-6">
                <a class="portfolio-box" href="img/portfolio/fullsize/1.jpeg">
                    <img class="img-fluid tam" src="img/portfolio/thumbnails/1.jpeg" alt="">
                    <div class="portfolio-box-caption">
                        <div class="project-category text-white-50">
                            Anticarsia gemmatalis
                        </div>
                        <div class="project-name overlay">
                            Lagarta da Soja
                        </div>
                    </div>
                </a>
            </div>

            <div class="col-lg-4 col-sm-6">
                <a class="portfolio-box" href="img/portfolio/fullsize/2.jpg">
                    <img class="img-fluid tam" src="img/portfolio/thumbnails/2.jpg" alt="">
                    <div class="portfolio-box-caption">
                        <div class="project-category text-white-50">
                          Euschistus heros
                        </div>
                        <div class="project-name">
                          Percevejo Marrom
                        </div>
                    </div>
                </a>
            </div>

            <div class="col-lg-4 col-sm-6">
                  <a class="portfolio-box" href="img/portfolio/fullsize/3.jpg" >
                      <img class="img-fluid tam" src="img/portfolio/thumbnails/3.jpg" alt="">
                      <div class="portfolio-box-caption" >
                          <div class="project-category text-white-50">
                            Diabrotica speciosa
                          </div>
                          <div class="project-name">
                            Vaquinha
                          </div>
                      </div>
                  </a>
            </div>

            <div class="col-lg-4 col-sm-6">
                <a class="portfolio-box" href="img/portfolio/fullsize/4.jpg">
                    <img class="img-fluid tam" src="img/portfolio/thumbnails/4.jpg" alt="">
                      <div class="portfolio-box-caption">
                          <div class="project-category text-white-50">
                            Julus hesperus
                          </div>
                          <div class="project-name">
                            Piolho-de-Cobra
                          </div>
                      </div>
                </a>
            </div>

            <div class="col-lg-4 col-sm-6">
              <a class="portfolio-box" href="img/portfolio/fullsize/5.jpg">
                <img class="img-fluid tam" src="img/portfolio/thumbnails/5.jpg" alt="">
                <div class="portfolio-box-caption">
                  <div class="project-category text-white-50">
                    Procornitermes triacifer
                  </div>
                  <div class="project-name">
                    Cupim-Subterrâneo
                  </div>
                </div>
              </a>
            </div>
        <div class="col-lg-4 col-sm-6">
          <a class="portfolio-box" href="img/portfolio/fullsize/6.jpg">
            <img class="img-fluid tam" src="img/portfolio/thumbnails/6.jpg" alt="">
            <div class="portfolio-box-caption p-3">
              <div class="project-category text-white-50">
                Anurogryllus muticus
              </div>
              <div class="project-name">
                Grilo Pardo
              </div>
            </div>
          </a>
        </div>
      </div>
    </div>
  </section>

  <!-- Call to Action Section -->
  <section class="page-section bg-dark text-white">
    <div class="container text-center">
      <h2 class="mb-4">Essa é uma amostra do nosso catálogo!</h2>
      <a class="btn btn-light btn-xl" href="#">Vá para o catálogo completo!</a>
    </div>
  </section>

  

  <!-- Contact Section -->
  <section class="page-section" id="contact">
      <div class="container">

         	<div class="row justify-content-center">
    	        <div class="col-lg-8 text-center">
      	          <h2 class="mt-0">Fale conosco!</h2>
      	          <hr class="divider my-4">
      	          <p class="text-muted mb-5">Gostou do projeto? Se deseja saber mais, realizar parcerias, catalogar uma praga que esteja faltando, tirar dúvidas ou dar sujestões, entre em contato pelos dados fornecidos a seguir ou preencha o formulário abaixo!</p>
    	        </div>
          </div>

          <div class="row">
    	      	<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 ml-auto text-center">
      	          <i class="fas fa-phone fa-3x mb-3 text-muted"></i>
      	          <div>+55 (35) 99111-3871</div>
                  <div>+55 (11) 99708-0791</div>
                  <div>+55 (11) 96408-2847</div>
    	        </div>

    	        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 ml-auto text-center">
    	        	  <i class="fab fa-3x mb-3 fa-instagram text-muted"></i>
    	            <div>soyp_pragas</div>
    	        </div>

    	        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 ml-auto text-center">
      	        	<i class="fab fa-3x fa-facebook mb-3 text-muted"></i>	        
      	          <div>Soyp - Pragas de Soja</div>
    	        </div>

    	        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 mr-auto text-center">
      	          <i class="fas fa-envelope fa-3x mb-3 text-muted"></i>
      	          <div>soyp_pragas@gmail.com</div>
    	        </div>
          </div>
        	

            <!-- FORMULÁRIO -->
        	<div class="row ">
            		<div class="col-lg-12">
                			<br><br>
            			    <form action="index.php#outro" method="POST">
                			    	<div class="form-group">
                  			    		<label for="exampleFormControlInput1">Nome Completo:</label>
                  			    		<input type="text" name="nome" class="form-control" id="nome" placeholder="Digite seu nome completo..." value="<?php if(isset($_POST['nome'])){echo $_POST['nome'];}?>">
                			  		</div>

                			  		<div class="form-group">
                  			    		<label for="exampleFormControlInput1">Email:</label>
                  			    		<input type="email" name="email" class="form-control" id="email" placeholder="Digite seu email..." value="<?php if(isset($_POST['email'])){echo $_POST['email'];}?>">
                			  		</div>

                			  		<div class="form-group">
                  			  			O que achou do Projeto?
                  				  		<div class="custom-control custom-radio">
                                    <input type="radio" id="customRadio1" name="radio" class="custom-control-input" value="Ótimo e diferente!" <?php echo (isset($_POST['radio']) && $_POST['radio']=="Ótimo e diferente!") ? "checked" : null; ?>>
                                    <label class="custom-control-label" for="customRadio1">Ótimo e diferente!</label>
                                </div>

                                <div class="custom-control custom-radio">
                                    <input type="radio" id="customRadio2" name="radio" class="custom-control-input" value="Bom, mas comum!" <?php echo (isset($_POST['radio']) && $_POST['radio']=="Bom, mas comum!") ? "checked" : null; ?>>
                                    <label class="custom-control-label" for="customRadio2">Bom, mas comum!</label>
                                </div>

                    						<div class="custom-control custom-radio">
                                    <input type="radio" id="customRadio3" name="radio" class="custom-control-input" value="Ruim, nada inovador!" <?php echo (isset($_POST['radio']) && $_POST['radio']=="Ruim, nada inovador!") ? "checked" : null; ?>>
                                    <label class="custom-control-label" for="customRadio3">Ruim, nada inovador!</label>
                                </div>
                					  </div>

                            <div class="form-group">
                                Como ficou sabendo do nosso projeto?
                                <div class="custom-control custom-checkbox">
                                  <input type="checkbox" class="custom-control-input" id="customCheck1" name="divulgacao[]" value="Redes Sociais" 
                                    <?php 
                                        if(isset($_POST['divulgacao'])){
                                          $divulgacao = $_POST['divulgacao']; 
                                          for ($i=0; $i < count($divulgacao); $i++) { 
                                            echo $divulgacao[$i]=="Redes Sociais" ? "checked" : null;
                                          }
                                        }
                                    ?>
                                  >
                                  <label class="custom-control-label" for="customCheck1">Redes Sociais</label>
                                </div>

                                <div class="custom-control custom-checkbox">
                                  <input type="checkbox" class="custom-control-input" id="customCheck2" name="divulgacao[]" value="Bragantec"
                                    <?php 
                                        if(isset($_POST['divulgacao'])){
                                          $divulgacao = $_POST['divulgacao']; 
                                          for ($i=0; $i < count($divulgacao); $i++) { 
                                            echo $divulgacao[$i]=="Bragantec" ? "checked" : null;
                                          }
                                        }
                                    ?>
                                  >
                                  <label class="custom-control-label" for="customCheck2">Bragantec</label>
                                </div>

                                <div class="custom-control custom-checkbox">
                                  <input type="checkbox" class="custom-control-input" id="customCheck3" name="divulgacao[]" value="Lojas de insumos agrícolas"
                                    <?php 
                                        if(isset($_POST['divulgacao'])){
                                          $divulgacao = $_POST['divulgacao']; 
                                          for ($i=0; $i < count($divulgacao); $i++) { 
                                            echo $divulgacao[$i]=="Lojas de insumos agrícolas" ? "checked" : null;
                                          }
                                        }
                                    ?>
                                  >
                                  <label class="custom-control-label" for="customCheck3">Lojas de insumos agrícolas</label>
                                </div>

                                <div class="custom-control custom-checkbox">
                                  <input type="checkbox" class="custom-control-input" id="customCheck4" name="divulgacao[]" value="Amigos, familiares ou conhecidos"
                                    <?php 
                                        if(isset($_POST['divulgacao'])){
                                          $divulgacao = $_POST['divulgacao']; 
                                          for ($i=0; $i < count($divulgacao); $i++) { 
                                            echo $divulgacao[$i]=="Amigos, familiares ou conhecidos" ? "checked" : null;
                                          }
                                        }
                                    ?>
                                  >
                                  <label class="custom-control-label" for="customCheck4">Amigos, familiares ou conhecidos</label>
                                </div>

                                <div class="custom-control custom-checkbox">
                                  <input type="checkbox" class="custom-control-input" id="customCheck5" name="divulgacao[]" value="Outros"
                                    <?php 
                                        if(isset($_POST['divulgacao'])){
                                          $divulgacao = $_POST['divulgacao']; 
                                          for ($i=0; $i < count($divulgacao); $i++) { 
                                            echo $divulgacao[$i]=="Outros" ? "checked" : null;
                                          }
                                        }
                                    ?>
                                  >
                                  <label class="custom-control-label" for="customCheck5">Outros</label>
                                </div>


                            </div>


                					  <div class="form-group">
                						    <label for="motivo">Assunto da Mensagem:</label>
                      						
                                <select name="motivo" id="assunto" class="form-control" >
                                    <option></option>
                        						<option value="1" <?php if (isset($_POST['motivo'])) {
                                      if ($_POST['motivo'] == 1) {echo "selected";} 
                                    } ?>>Cadastro de nova praga</option>
                  							    <option value="2" <?php if (isset($_POST['motivo'])) {
                                      if ($_POST['motivo'] == 2) {echo "selected";} 
                                    }  ?>>Parcerias</option>
                  							    <option value="3" <?php if (isset($_POST['motivo'])) {
                                      if ($_POST['motivo'] == 3) {echo "selected";} 
                                    }  ?>>Conhecer mais do projeto</option>
                  							    <option value="4" <?php if (isset($_POST['motivo'])) {
                                      if ($_POST['motivo'] == 4) {echo "selected";} 
                                    }  ?>>Conhecer melhor o aplicativo</option>
                  							    <option value="5" <?php if (isset($_POST['motivo'])) {
                                      if ($_POST['motivo'] == 5) {echo "selected";} 
                                    }  ?>>Dúvidas</option>
                  							    <option value="6" <?php if (isset($_POST['motivo'])) {
                                      if ($_POST['motivo'] == 6) {echo "selected";} 
                                    }  ?>>Sugestões</option>
                  							    <option value="7" <?php if (isset($_POST['motivo'])) {
                                      if ($_POST['motivo'] == 7) {echo "selected";} 
                                    }  ?>>Outros</option>
                      					</select>

                					  </div>
                      						
                      			<div class="form-group" id="outro">
                			    			<label for="exampleFormControlInput1">Outro Assunto:</label>
                			    			<input type="text" class="form-control" placeholder="Informe o assunto" name="outro" value="<?php if(isset($_POST['outro'])){echo $_POST['outro'];}?>">
                			  		</div>
                    				
                			  		<div class="form-group">
                  			    		<label for="exampleFormControlTextarea1">Mensagem:</label>

                  			    		<textarea  name="mensagem" class="form-control" id="mensagem" rows="3"><?php if(isset($_POST['mensagem'])){echo $_POST['mensagem'];} ?></textarea>
                			  		</div>

                			  		<div class="form-group">
                  			  			
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" id="customFile">
                                    <label class="custom-file-label" for="customFile"><i class="fas fa-1x fa-paperclip"></i> Anexar arquivos</label>
                                </div>
                			  		</div>

                			  		<div class="form-group">
                              
                			  			<input type="submit" name="enviar" value="Enviar" class="btn btn-success btn-xl js-scroll-trigger" id="enviar">
                             
                			        <input type="reset" name="limpar" value="Limpar" class="btn btn-success btn-xl js-scroll-trigger">
                            
                			  		</div>
            				</form>
        			</div>
    		  </div>

          <div class="row">
            <div class="col-lg-12">

                <?php 
                  if (isset($erro) && strlen($erro)>0) {
                ?>
                    <div class="alert alert-danger">
                      
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                      </button>
                      <h3>Erro ao enviar o formulário!</h3>
                      <hr>
                      <strong>Preencha corretamente os campos indicados a seguir:</strong>
                      <br>
                      <?php echo $erro; ?>
                    </div>
                <?php
                  }else{
                ?>
                    <div class="alert alert-success">
                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                      </button>
                      <h3>Sua mensagem enviada com Sucesso!</h3>
                      <hr>
                      
                      <?php 
                          echo "<strong>Nome:</strong> " . $usuario->getNome() . "<br>";
                          echo "<strong>Email:</strong> " . $usuario->getEmail() . "<br>";
                          echo "<strong>Opinião sobre o projeto:</strong> " . $avaliacao->getOpiniao() . "<br>";
                          echo "<strong>Como ficou sabendo do projeto:</strong> <br>";
                          for($i=0; $i<count($divulgacao); $i++){
                              echo "  ". ($i+1) . ") " . $divulgacao[$i] . "<br>";
                          }
                          echo "<strong>Assunto da Mensagem:</strong> " . $mensagem->getAssunto() . "<br>";
                          echo "<strong>Mensagem:</strong> " . $mensagem->getMsg() . "<br>";
                      ?>
                    </div>
                <?php
                    
                  }
                ?>
            </div>
          </div>

  </section>


    	<!-- Contact Section -->
      <section class="page-section bg-dark cor" id="desenvolvedores">
      		<div class="container">		

    	        <div class="row">
    	        	<div class="col-lg-12 text-center">
    	        		<h2 class="mt-0">Desenvolvedores!</h2>
    	         		<hr class="divider my-4">
    	        	</div>
    	        	
              <div class="col-lg-4 col-md-4 col-sm-12 text-center">
                <figure>  
                  <img src="img/mari.jpg" alt="Mariane Siqueira" class="rounded-circle img-thumbnail img-fluid">
                  <br><br>
                </figure>
                
                    <i class="fab fa-2x fa-facebook-square"></i> <h6>Mariana Siqueira</h6>
                    <br>
                    <i class="fab fa-2x fa-instagram"></i> <h6>Mari_sillva</h6>
                    <br>
                    <i class="fas fa-2x fa-envelope"></i><h6>marianasiqueira2001@outlook.com.br</h6>
                
                
              </div>

      				<div class="col-lg-4 col-md-4 col-sm-12 text-center">
      					<figure>
      						<img src="img/caua.jpg" alt="Cauã Reis" class="rounded-circle img-thumbnail img-fluid">
      						<br><br>
                </figure>
      						
      							<i class="fab fa-2x fa-facebook-square"></i> <h6>Caua Reis</h6>
      							<br>
      							<i class="fab fa-2x fa-instagram"></i> <h6>Caua95</h6>
      							<br>
      							<i class="fas fa-2x fa-envelope"></i> <h6>cauareis23@gmail.com</h6>
      						
      					
      				</div>

      				

      				<div class="col-lg-4 col-md-4 col-sm-12 text-center">
      					<figure>
      						<img src="img/rai.jpg" alt="Raiane Esheley" class="rounded-circle img-thumbnail img-fluid">
      						<br><br>
      						</figure>
      							<i class="fab fa-2x fa-facebook-square"></i> <h6>Raiane Esheley</h6>
      							<br>
      							<i class="fab fa-2x fa-instagram"></i> <h6>Raiane29</h6>
      							<br>
      							<i class="fas fa-2x fa-envelope"></i> <h6>raianeesheley0@gmail.com</h6>
      						
      				</div>
      			</div>
      		</div>
  </section>



  <!-- Footer -->
  <footer class="bg-light py-5">
    <div class="container">
      <div class="small text-center text-muted">Copyright &copy; 2019 - SOYP - Identificador de Pragas de Soja</div>
    </div>
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
  <script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

  <!-- Custom scripts for this template -->
  <script src="js/creative.min.js"></script>

</body>

</html>
