$(document).ready(
	function(){
			/* VALIDAÇÃO DO FORMULÁRIO 
			var nome = $('#nome').val();
			var email = $('#email').val();

			if (nome.length()==0 && (email.length()==0 || email)) {}*/

			/* NAVEGAÇÃO INTERATIVA DA PÁGINA*/
			

			$('#mo').hide();
			$('#hc').hide();
			$('#ec').hide();
			$('#ut').hide();
			
			$('#outro').hide();

			$('#assunto').click(
				function (){
					if ($('#assunto').val()== 7){
						$('#assunto').parent().next($('#outro').slideDown());
					}else{
						$('#assunto').parent().next($('#outro').slideUp());
					}
				}
			)


			$('#historia').click(
				function (){
					
						if($('#ec').is(':visible') || $('#ut').is(':visible') || $('#mo').is(':visible') ){
							$('#historia').parent().parent().parent().parent().parent().next($('#ec').hide());
							$('#historia').parent().parent().parent().parent().parent().next($('#ut').hide());
							$('#historia').parent().parent().parent().parent().parent().next($('#mo').hide());
							$('#historia').parent().parent().parent().parent().parent().next($('#hc').show());
						}else{
							if($('#hc').is(':visible')){
								$('#historia').parent().parent().parent().parent().parent().next($('#hc').hide());
							}else{
								if($('#hc').is(':hidden') && $('#ut').is(':hidden') && $('#mo').is(':hidden') && $('#ec').is(':hidden') ){
									$('#historia').parent().parent().parent().parent().parent().next($('#hc').show());
								}
							}
						}
						
					
				}
			)

			$('#utilizacao').click(
				function (){
					
						if($('#ec').is(':visible') || $('#hc').is(':visible') || $('#mo').is(':visible') ){
							$('#utilizacao').parent().parent().parent().parent().parent().next($('#ec').hide());
							$('#utilizacao').parent().parent().parent().parent().parent().next($('#hc').hide());
							$('#utilizacao').parent().parent().parent().parent().parent().next($('#mo').hide());
							$('#utilizacao').parent().parent().parent().parent().parent().next($('#ut').show());
						}else{
							if($('#ut').is(':visible')){
								$('#utilizacao').parent().parent().parent().parent().parent().next($('#ut').hide());
							}else{
								if($('#ut').is(':hidden') && $('#hc').is(':hidden') && $('#mo').is(':hidden') && $('#ec').is(':hidden') ){
									$('#utilizacao').parent().parent().parent().parent().parent().next($('#ut').show());
								}
							}
						}
						
					
				}
			)

			$('.fechar').click(
					function(){
						$('#historia').parent().parent().parent().parent().parent().next($('#hc').hide());
						$('#historia').parent().parent().parent().parent().parent().next($('#ut').hide());
						$('#historia').parent().parent().parent().parent().parent().next($('#mo').hide());
						$('#historia').parent().parent().parent().parent().parent().next($('#ec').hide());
					}
			)

			$('#economia').click(
				function (){
					
						if($('#hc').is(':visible') || $('#ut').is(':visible') || $('#mo').is(':visible') ){
							$('#economia').parent().parent().parent().parent().parent().next($('#hc').hide());
							$('#economia').parent().parent().parent().parent().parent().next($('#ut').hide());
							$('#economia').parent().parent().parent().parent().parent().next($('#mo').hide());
							$('#economia').parent().parent().parent().parent().parent().next($('#ec').show());
						}else{
							if($('#ec').is(':visible')){
								$('#economia').parent().parent().parent().parent().parent().next($('#ec').hide());
							}else{
								if($('#hc').is(':hidden') && $('#ut').is(':hidden') && $('#mo').is(':hidden') && $('#ec').is(':hidden') ){
									$('#economia').parent().parent().parent().parent().parent().next($('#ec').show());
								}
							}
						}
				}
			)

			$('#morfologia').click(
				function (){
					
						if($('#hc').is(':visible') || $('#ut').is(':visible') || $('#ec').is(':visible') ){
							$('#morfologia').parent().parent().parent().parent().parent().next($('#hc').hide());
							$('#morfologia').parent().parent().parent().parent().parent().next($('#ut').hide());
							$('#morfologia').parent().parent().parent().parent().parent().next($('#ec').hide());
							$('#morfologia').parent().parent().parent().parent().parent().next($('#mo').show());
						}else{
							if($('#mo').is(':visible')){
								$('#morfologia').parent().parent().parent().parent().parent().next($('#mo').hide());
							}else{
								if($('#hc').is(':hidden') && $('#ut').is(':hidden') && $('#ec').is(':hidden') && $('#mo').is(':hidden') ){
									$('#morfologia').parent().parent().parent().parent().parent().next($('#mo').show());
								}
							}
						}
				}
			)

			


			


			
	}
)

